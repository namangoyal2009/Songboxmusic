'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import Card from '@/components/ui/Card';
import TrackList from '@/components/track/TrackList';
import PersonalizedGreeting from '@/components/home/PersonalizedGreeting';
import MoodPlaylists from '@/components/home/MoodPlaylists';
import { fetchTrendingTracks, fetchTrackMetadata } from '@/lib/audius';
import { generateRecommendations } from '@/lib/recommendations';
import { useUserStore } from '@/store/userStore';
import { Track } from '@/types/track';

export default function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [trendingTracks, setTrendingTracks] = useState<Track[]>([]);
  const [recommendedTracks, setRecommendedTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingRecommendations, setLoadingRecommendations] = useState(true);

  const { likedSongs, listeningHistory } = useUserStore();

  useEffect(() => {
    loadTracks();
  }, []);

  useEffect(() => {
    loadRecommendations();
  }, [likedSongs, listeningHistory]);

  async function loadTracks() {
    setLoading(true);
    const data = await fetchTrendingTracks(10);
    setTrendingTracks(data);
    setLoading(false);
  }

  async function loadRecommendations() {
    setLoadingRecommendations(true);

    try {
      // Combine liked songs and listening history for recommendations
      const uniqueTrackIds = new Set([
        ...Array.from(likedSongs),
        ...listeningHistory.slice(0, 30).map((h) => h.trackId),
      ]);

      // Fetch track metadata
      const tracks = await Promise.all(
        Array.from(uniqueTrackIds)
          .slice(0, 30)
          .map((id) => fetchTrackMetadata(id))
      );

      const validTracks = tracks.filter((t) => t !== null) as Track[];

      // Generate recommendations
      const userProfile = {
        likedSongs,
        listeningHistory: listeningHistory.slice(0, 50),
      };

      const recommended = await generateRecommendations(userProfile, validTracks, 10);
      setRecommendedTracks(recommended);
    } catch (error) {
      console.error('Error loading recommendations:', error);
    } finally {
      setLoadingRecommendations(false);
    }
  }

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* 3D Visualizer Background */}
      <VisualizerCanvas />

      {/* Top Navigation Bar */}
      <TopBar onMenuToggle={() => setMenuOpen(true)} />

      {/* Side Menu */}
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      {/* Main Content */}
      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        {/* Personalized Greeting with AI */}
        <PersonalizedGreeting />

        {/* Quick Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/trending">
            <Card hover padding="lg" className="cursor-pointer group h-full">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                    Trending Now
                  </h3>
                  <p className="text-sm text-foreground-secondary">
                    Discover what's hot
                  </p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/library">
            <Card hover padding="lg" className="cursor-pointer group h-full">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-secondary to-secondary-dark flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-secondary transition-colors">
                    Your Library
                  </h3>
                  <p className="text-sm text-foreground-secondary">
                    Playlists & liked songs
                  </p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/downloads">
            <Card hover padding="lg" className="cursor-pointer group h-full">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-purple-500 transition-colors">
                    Downloads
                  </h3>
                  <p className="text-sm text-foreground-secondary">
                    Offline playback
                  </p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/search">
            <Card hover padding="lg" className="cursor-pointer group h-full">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-success to-emerald-600 flex items-center justify-center flex-shrink-0">
                  <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-success transition-colors">
                    Search
                  </h3>
                  <p className="text-sm text-foreground-secondary">
                    Find your favorite tracks
                  </p>
                </div>
              </div>
            </Card>
          </Link>
        </div>

        {/* AI Recommended Tracks */}
        {recommendedTracks.length > 0 && (
          <GlassPanel className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-1 flex items-center gap-2">
                  <span>Recommended for You</span>
                  <span className="text-xl">🎯</span>
                </h2>
                <p className="text-sm text-foreground-secondary">
                  Personalized picks based on your taste
                </p>
              </div>
            </div>

            {loadingRecommendations ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={i}
                    className="bg-white/5 rounded-lg h-64 animate-pulse shimmer"
                  />
                ))}
              </div>
            ) : (
              <TrackList tracks={recommendedTracks} columns={5} />
            )}
          </GlassPanel>
        )}

        {/* Trending Tracks Section */}
        <GlassPanel className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-1">
                Trending Tracks
              </h2>
              <p className="text-sm text-foreground-secondary">
                Popular right now on Audius
              </p>
            </div>
            <Link
              href="/trending"
              className="text-primary hover:text-primary-light transition-colors text-sm font-medium"
            >
              See all →
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="bg-white/5 rounded-lg h-64 animate-pulse shimmer"
                />
              ))}
            </div>
          ) : (
            <TrackList tracks={trendingTracks} columns={5} />
          )}
        </GlassPanel>

        {/* AI-Generated Mood Playlists */}
        <MoodPlaylists />

        {/* Phase 6 Complete Banner */}
        <GlassPanel className="text-center py-8 mt-12">
          <div className="inline-block p-4 rounded-full bg-success/10 mb-4">
            <svg className="w-12 h-12 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Phase 6: Lyrics & AI Features Complete! 🤖✨
          </h2>
          <p className="text-foreground-secondary max-w-2xl mx-auto mb-4">
            Songbox now features powerful AI-driven recommendations, mood-based playlists, personalized greetings,
            offline downloads, background playback, and synchronized lyrics! Your music experience just got smarter.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-sm text-foreground-muted">
            <span>🎯 AI Recommendations</span>
            <span>🎵 Lyrics Integration</span>
            <span>📥 Offline Downloads</span>
            <span>🎭 Mood Playlists</span>
            <span>🎧 Background Playback</span>
          </div>
        </GlassPanel>
      </main>

      {/* Bottom Player Bar */}
      <BottomPlayer />
    </div>
  );
}
