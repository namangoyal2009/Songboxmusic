import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import PWALifecycle from '@/components/pwa/PWALifecycle';
import ToastContainer from '@/components/ui/Toast';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Songbox - 3D Music Streaming',
  description: 'Immersive 3D music streaming powered by Audius with AI recommendations, offline playback, and synchronized lyrics',
  keywords: ['music', 'streaming', '3D', 'Audius', 'AI', 'offline', 'PWA'],
  authors: [{ name: 'Songbox Team' }],
  creator: 'Songbox',
  publisher: 'Songbox',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Songbox',
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://songbox.app',
    title: 'Songbox - 3D Music Streaming',
    description: 'Immersive 3D music streaming powered by Audius',
    siteName: 'Songbox',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Songbox - 3D Music Streaming',
    description: 'Immersive 3D music streaming powered by Audius',
  },
  icons: {
    icon: [
      { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: [
      { url: '/icons/icon-152x152.png', sizes: '152x152', type: 'image/png' },
      { url: '/icons/icon-180x180.png', sizes: '180x180', type: 'image/png' },
    ],
  },
};

export const viewport: Viewport = {
  themeColor: '#6366f1',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Songbox" />
      </head>
      <body className={inter.className}>
        <PWALifecycle />
        <ToastContainer />
        {children}
      </body>
    </html>
  );
}
