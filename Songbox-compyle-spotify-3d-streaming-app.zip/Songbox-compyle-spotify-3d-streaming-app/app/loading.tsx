import Loading from '@/components/ui/Loading';

export default function LoadingPage() {
  return <Loading fullScreen message="Loading Songbox..." />;
}
