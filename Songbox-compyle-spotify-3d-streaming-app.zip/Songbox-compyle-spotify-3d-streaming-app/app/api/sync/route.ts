import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';
import { supabase } from '@/lib/supabase';

// POST - Sync local data to server
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { likedSongs, playlists, listeningHistory } = await req.json();

    // Sync liked songs
    if (likedSongs && Array.isArray(likedSongs)) {
      const likedSongsData = likedSongs.map((trackId) => ({
        user_id: session.user.id,
        audius_track_id: trackId,
      }));

      await supabase
        .from('liked_songs')
        .upsert(likedSongsData, { onConflict: 'user_id,audius_track_id', ignoreDuplicates: true });
    }

    // Sync playlists
    if (playlists && Array.isArray(playlists)) {
      for (const playlist of playlists) {
        const { data: newPlaylist } = await supabase
          .from('playlists')
          .insert({
            user_id: session.user.id,
            name: playlist.name,
            description: playlist.description,
            is_public: playlist.isPublic || false,
          })
          .select()
          .single();

        if (newPlaylist && playlist.trackIds) {
          const playlistTracks = playlist.trackIds.map((trackId: string, index: number) => ({
            playlist_id: newPlaylist.id,
            audius_track_id: trackId,
            position: index,
          }));

          await supabase.from('playlist_tracks').insert(playlistTracks);
        }
      }
    }

    // Sync listening history
    if (listeningHistory && Array.isArray(listeningHistory)) {
      const historyData = listeningHistory.map((entry) => ({
        user_id: session.user.id,
        audius_track_id: entry.trackId,
        played_at: entry.playedAt,
        duration_seconds: entry.durationSeconds,
      }));

      await supabase.from('listening_history').insert(historyData);
    }

    return NextResponse.json({ success: true, message: 'Data synced successfully' });
  } catch (error) {
    console.error('Error syncing data:', error);
    return NextResponse.json({ error: 'Failed to sync data' }, { status: 500 });
  }
}

// GET - Fetch all user data from server
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Fetch all user data
    const [likedSongsRes, playlistsRes, historyRes] = await Promise.all([
      supabase
        .from('liked_songs')
        .select('audius_track_id')
        .eq('user_id', session.user.id),
      supabase
        .from('playlists')
        .select('*, playlist_tracks(audius_track_id, position)')
        .eq('user_id', session.user.id),
      supabase
        .from('listening_history')
        .select('audius_track_id, played_at, duration_seconds')
        .eq('user_id', session.user.id)
        .order('played_at', { ascending: false })
        .limit(100),
    ]);

    const likedSongs = likedSongsRes.data?.map((s) => s.audius_track_id) || [];

    const playlists =
      playlistsRes.data?.map((p: any) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        coverImageUrl: p.cover_image_url,
        isPublic: p.is_public,
        trackIds: p.playlist_tracks
          .sort((a: any, b: any) => a.position - b.position)
          .map((t: any) => t.audius_track_id),
        createdAt: p.created_at,
        updatedAt: p.updated_at,
      })) || [];

    const listeningHistory =
      historyRes.data?.map((h) => ({
        trackId: h.audius_track_id,
        playedAt: h.played_at,
        durationSeconds: h.duration_seconds,
      })) || [];

    return NextResponse.json({
      likedSongs,
      playlists,
      listeningHistory,
    });
  } catch (error) {
    console.error('Error fetching user data:', error);
    return NextResponse.json({ error: 'Failed to fetch user data' }, { status: 500 });
  }
}
