import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';
import { supabase } from '@/lib/supabase';

// GET - Fetch listening history
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');

    const { data, error } = await supabase
      .from('listening_history')
      .select('audius_track_id, played_at, duration_seconds')
      .eq('user_id', session.user.id)
      .order('played_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return NextResponse.json({ history: data });
  } catch (error) {
    console.error('Error fetching history:', error);
    return NextResponse.json({ error: 'Failed to fetch history' }, { status: 500 });
  }
}

// POST - Add to listening history
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);

  try {
    const { trackId, durationSeconds } = await req.json();

    if (!trackId || durationSeconds === undefined) {
      return NextResponse.json({ error: 'Track ID and duration required' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('listening_history')
      .insert({
        user_id: session?.user?.id || null,
        audius_track_id: trackId,
        duration_seconds: durationSeconds,
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ success: true, entry: data });
  } catch (error) {
    console.error('Error adding to history:', error);
    return NextResponse.json({ error: 'Failed to add to history' }, { status: 500 });
  }
}
