import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]/route';
import { supabase } from '@/lib/supabase';

// GET - Fetch user's liked songs
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { data, error } = await supabase
      .from('liked_songs')
      .select('audius_track_id, liked_at')
      .eq('user_id', session.user.id)
      .order('liked_at', { ascending: false });

    if (error) throw error;

    return NextResponse.json({ likedSongs: data });
  } catch (error) {
    console.error('Error fetching liked songs:', error);
    return NextResponse.json({ error: 'Failed to fetch liked songs' }, { status: 500 });
  }
}

// POST - Add a liked song
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { trackId } = await req.json();

    if (!trackId) {
      return NextResponse.json({ error: 'Track ID required' }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('liked_songs')
      .insert({
        user_id: session.user.id,
        audius_track_id: trackId,
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ success: true, likedSong: data });
  } catch (error) {
    console.error('Error adding liked song:', error);
    return NextResponse.json({ error: 'Failed to add liked song' }, { status: 500 });
  }
}

// DELETE - Remove a liked song
export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const trackId = searchParams.get('trackId');

    if (!trackId) {
      return NextResponse.json({ error: 'Track ID required' }, { status: 400 });
    }

    const { error } = await supabase
      .from('liked_songs')
      .delete()
      .eq('user_id', session.user.id)
      .eq('audius_track_id', trackId);

    if (error) throw error;

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error removing liked song:', error);
    return NextResponse.json({ error: 'Failed to remove liked song' }, { status: 500 });
  }
}
