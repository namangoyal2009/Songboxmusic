import { NextRequest, NextResponse } from 'next/server';

// API route to fetch lyrics (proxies requests to avoid CORS and keep API keys secure)
export async function GET(req: NextRequest) {
  const searchParams = req.nextUrl.searchParams;
  const artist = searchParams.get('artist');
  const title = searchParams.get('title');

  if (!artist || !title) {
    return NextResponse.json({ error: 'Missing artist or title parameter' }, { status: 400 });
  }

  try {
    // Try Lyrics.ovh first
    const lyricsOvhResponse = await fetch(
      `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    );

    if (lyricsOvhResponse.ok) {
      const data = await lyricsOvhResponse.json();
      if (data.lyrics) {
        return NextResponse.json({
          lyrics: data.lyrics,
          source: 'lyrics.ovh',
        });
      }
    }

    // If Lyrics.ovh fails, try Musixmatch (if API key is configured)
    const musixmatchApiKey = process.env.MUSIXMATCH_API_KEY;

    if (musixmatchApiKey) {
      // Search for the track
      const searchResponse = await fetch(
        `https://api.musixmatch.com/ws/1.1/track.search?` +
          `q_artist=${encodeURIComponent(artist)}&` +
          `q_track=${encodeURIComponent(title)}&` +
          `apikey=${musixmatchApiKey}`
      );

      if (searchResponse.ok) {
        const searchData = await searchResponse.json();
        const trackList = searchData.message?.body?.track_list;

        if (trackList && trackList.length > 0) {
          const trackId = trackList[0].track.track_id;

          // Fetch the lyrics
          const lyricsResponse = await fetch(
            `https://api.musixmatch.com/ws/1.1/track.lyrics.get?track_id=${trackId}&apikey=${musixmatchApiKey}`
          );

          if (lyricsResponse.ok) {
            const lyricsData = await lyricsResponse.json();
            const lyricsBody = lyricsData.message?.body?.lyrics?.lyrics_body;

            if (lyricsBody) {
              return NextResponse.json({
                lyrics: lyricsBody,
                source: 'musixmatch',
              });
            }
          }
        }
      }
    }

    // No lyrics found from either source
    return NextResponse.json(
      {
        error: 'Lyrics not found',
        message: 'Lyrics are not available for this track from any source',
      },
      { status: 404 }
    );
  } catch (error) {
    console.error('Error fetching lyrics:', error);
    return NextResponse.json(
      {
        error: 'Failed to fetch lyrics',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}
