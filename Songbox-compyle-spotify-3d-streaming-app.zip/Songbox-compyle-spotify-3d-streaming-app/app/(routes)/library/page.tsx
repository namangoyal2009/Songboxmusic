'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import Button from '@/components/ui/Button';
import TrackList from '@/components/track/TrackList';
import { useUserStore } from '@/store/userStore';
import { Track } from '@/types/track';
import { fetchTrackMetadata } from '@/lib/audius';
import AuthModal from '@/components/auth/AuthModal';

export default function LibraryPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'liked' | 'playlists' | 'history'>('liked');
  const [likedTracks, setLikedTracks] = useState<Track[]>([]);
  const [historyTracks, setHistoryTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');

  const { data: session } = useSession();
  const { likedSongs, playlists, listeningHistory, addPlaylist } = useUserStore();

  useEffect(() => {
    loadLikedTracks();
  }, [likedSongs]);

  const loadLikedTracks = async () => {
    setLoading(true);
    try {
      const trackIds = Array.from(likedSongs);
      const tracks = await Promise.all(
        trackIds.slice(0, 50).map((id) => fetchTrackMetadata(id))
      );
      setLikedTracks(tracks.filter((t) => t !== null) as Track[]);
    } catch (error) {
      console.error('Error loading liked tracks:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHistoryTracks = async () => {
    setLoading(true);
    try {
      const uniqueTrackIds = Array.from(
        new Set(listeningHistory.map((h) => h.trackId))
      ).slice(0, 50);
      const tracks = await Promise.all(
        uniqueTrackIds.map((id) => fetchTrackMetadata(id))
      );
      setHistoryTracks(tracks.filter((t) => t !== null) as Track[]);
    } catch (error) {
      console.error('Error loading history tracks:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'history') {
      loadHistoryTracks();
    }
  }, [activeTab, listeningHistory]);

  const handleCreatePlaylist = () => {
    if (!newPlaylistName.trim()) return;

    const newPlaylist = {
      id: Date.now().toString(),
      name: newPlaylistName,
      trackIds: [],
      isPublic: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    addPlaylist(newPlaylist);
    setNewPlaylistName('');
    setShowCreatePlaylist(false);
  };

  if (!session) {
    return (
      <div className="min-h-screen bg-background">
        <VisualizerCanvas />
        <TopBar onMenuToggle={() => setMenuOpen(true)} />
        <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

        <main className="pt-20 pb-24 px-4 md:px-8 max-w-4xl mx-auto">
          <GlassPanel className="text-center py-12">
            <h1 className="text-2xl font-bold text-foreground mb-4">Library</h1>
            <p className="text-foreground-secondary mb-6">
              Your library works without an account, but sign in to sync across devices!
            </p>
            <Button onClick={() => setShowAuth(true)} variant="primary">
              Sign In / Sign Up
            </Button>
          </GlassPanel>
        </main>

        <BottomPlayer />
        <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />
      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        <GlassPanel className="mb-6">
          <h1 className="text-3xl font-bold text-foreground mb-4">Your Library</h1>

          {/* Tabs */}
          <div className="flex gap-2 border-b border-white/10">
            {[
              { id: 'liked', label: 'Liked Songs', count: likedSongs.size },
              { id: 'playlists', label: 'Playlists', count: playlists.length },
              { id: 'history', label: 'History', count: listeningHistory.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                  activeTab === tab.id
                    ? 'text-primary border-primary'
                    : 'text-foreground-secondary border-transparent hover:text-foreground'
                }`}
              >
                {tab.label} ({tab.count})
              </button>
            ))}
          </div>
        </GlassPanel>

        {/* Liked Songs */}
        {activeTab === 'liked' && (
          <GlassPanel>
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-white/5 rounded-lg h-64 animate-pulse" />
                ))}
              </div>
            ) : likedTracks.length > 0 ? (
              <TrackList tracks={likedTracks} columns={5} />
            ) : (
              <div className="text-center py-12">
                <p className="text-foreground-secondary">
                  No liked songs yet. Start liking tracks to build your collection!
                </p>
              </div>
            )}
          </GlassPanel>
        )}

        {/* Playlists */}
        {activeTab === 'playlists' && (
          <div className="space-y-4">
            <GlassPanel>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-foreground">Your Playlists</h2>
                <Button onClick={() => setShowCreatePlaylist(true)} variant="primary" size="sm">
                  Create Playlist
                </Button>
              </div>

              {showCreatePlaylist && (
                <div className="mb-4 p-4 bg-white/5 rounded-lg">
                  <input
                    type="text"
                    placeholder="Playlist name..."
                    value={newPlaylistName}
                    onChange={(e) => setNewPlaylistName(e.target.value)}
                    className="w-full px-4 py-2 bg-background-surface border border-white/10 rounded-lg text-foreground mb-3"
                    onKeyDown={(e) => e.key === 'Enter' && handleCreatePlaylist()}
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleCreatePlaylist} variant="primary" size="sm">
                      Create
                    </Button>
                    <Button onClick={() => setShowCreatePlaylist(false)} variant="ghost" size="sm">
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {playlists.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {playlists.map((playlist) => (
                    <div
                      key={playlist.id}
                      className="bg-white/5 rounded-lg p-4 hover:bg-white/10 transition-all cursor-pointer"
                    >
                      <div className="aspect-square rounded-md bg-gradient-to-br from-primary/30 to-secondary/30 mb-3 flex items-center justify-center">
                        <svg
                          className="w-12 h-12 text-white/50"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                        </svg>
                      </div>
                      <h3 className="font-medium text-foreground line-clamp-2 mb-1">{playlist.name}</h3>
                      <p className="text-sm text-foreground-secondary">{playlist.trackIds.length} tracks</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-foreground-secondary">
                    No playlists yet. Create your first playlist!
                  </p>
                </div>
              )}
            </GlassPanel>
          </div>
        )}

        {/* History */}
        {activeTab === 'history' && (
          <GlassPanel>
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-white/5 rounded-lg h-64 animate-pulse" />
                ))}
              </div>
            ) : historyTracks.length > 0 ? (
              <TrackList tracks={historyTracks} columns={5} />
            ) : (
              <div className="text-center py-12">
                <p className="text-foreground-secondary">
                  No listening history yet. Start playing some tracks!
                </p>
              </div>
            )}
          </GlassPanel>
        )}
      </main>

      <BottomPlayer />
    </div>
  );
}
