'use client';

import { useState, useEffect } from 'react';
import { useSession, signOut } from 'next-auth/react';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import Button from '@/components/ui/Button';
import { useUserStore } from '@/store/userStore';
import { useTheme } from '@/lib/hooks/useTheme';
import AuthModal from '@/components/auth/AuthModal';

export default function SettingsPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const { data: session } = useSession();
  const { user, updatePreferences } = useUserStore();
  const { theme, setTheme } = useTheme();
  const [visualizerMode, setVisualizerMode] = useState<'auto' | 'particle' | 'wave' | 'shapes'>('auto');
  const [vibeMode, setVibeMode] = useState(true);

  useEffect(() => {
    if (user?.preferences) {
      setVisualizerMode(user.preferences.visualizerMode);
      setVibeMode(user.preferences.vibeMode);
    }
  }, [user]);

  const handleVisualizerChange = (mode: 'auto' | 'particle' | 'wave' | 'shapes') => {
    setVisualizerMode(mode);
    updatePreferences({ visualizerMode: mode });
  };

  const handleVibeModeToggle = () => {
    const newValue = !vibeMode;
    setVibeMode(newValue);
    updatePreferences({ vibeMode: newValue });
  };

  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/' });
  };

  const syncData = async () => {
    if (!session) return;

    try {
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          likedSongs: useUserStore.getState().getLikedSongs(),
          playlists: useUserStore.getState().playlists,
          listeningHistory: useUserStore.getState().listeningHistory,
        }),
      });

      if (response.ok) {
        alert('Data synced successfully!');
      }
    } catch (error) {
      console.error('Sync error:', error);
      alert('Failed to sync data');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />

      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-4xl mx-auto space-y-6">
        <GlassPanel>
          <h1 className="text-3xl font-bold text-foreground mb-2">Settings</h1>
          <p className="text-foreground-secondary">Customize your Songbox experience</p>
        </GlassPanel>

        {/* Account Section */}
        <GlassPanel>
          <h2 className="text-xl font-bold text-foreground mb-4">Account</h2>
          {session ? (
            <div className="space-y-4">
              <div>
                <p className="text-sm text-foreground-secondary mb-1">Signed in as</p>
                <p className="text-foreground font-medium">{session.user?.email}</p>
              </div>
              <div className="flex gap-3">
                <Button onClick={syncData} variant="outline">
                  Sync Data to Cloud
                </Button>
                <Button onClick={handleSignOut} variant="danger">
                  Sign Out
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-foreground-secondary">
                Sign in to sync your data across devices and access cloud features
              </p>
              <Button onClick={() => setShowAuth(true)} variant="primary">
                Sign In / Sign Up
              </Button>
            </div>
          )}
        </GlassPanel>

        {/* Appearance Section */}
        <GlassPanel>
          <h2 className="text-xl font-bold text-foreground mb-4">Appearance</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Theme</label>
              <div className="flex gap-3">
                <Button
                  onClick={() => setTheme('dark')}
                  variant={theme === 'dark' ? 'primary' : 'outline'}
                  size="sm"
                >
                  Dark
                </Button>
                <Button
                  onClick={() => setTheme('light')}
                  variant={theme === 'light' ? 'primary' : 'outline'}
                  size="sm"
                >
                  Light
                </Button>
              </div>
            </div>
          </div>
        </GlassPanel>

        {/* Visualizer Section */}
        <GlassPanel>
          <h2 className="text-xl font-bold text-foreground mb-4">Visualizer</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Visualizer Mode</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: 'auto', label: 'Auto (Based on mood)' },
                  { value: 'particle', label: 'Particle Field' },
                  { value: 'wave', label: 'Geometric Wave' },
                  { value: 'shapes', label: 'Abstract Shapes' },
                ].map((mode) => (
                  <Button
                    key={mode.value}
                    onClick={() => handleVisualizerChange(mode.value as any)}
                    variant={visualizerMode === mode.value ? 'primary' : 'outline'}
                    size="sm"
                  >
                    {mode.label}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-foreground">Vibe Mode</p>
                  <p className="text-xs text-foreground-secondary mt-1">
                    Dynamic colors based on song mood
                  </p>
                </div>
                <button
                  onClick={handleVibeModeToggle}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    vibeMode ? 'bg-primary' : 'bg-white/10'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      vibeMode ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </GlassPanel>

        {/* About Section */}
        <GlassPanel>
          <h2 className="text-xl font-bold text-foreground mb-4">About</h2>
          <div className="space-y-2 text-sm">
            <p className="text-foreground-secondary">
              <strong className="text-foreground">Songbox</strong> - 3D Music Streaming Experience
            </p>
            <p className="text-foreground-secondary">Version 1.0.0</p>
            <p className="text-foreground-secondary">
              Music powered by <a href="https://audius.co" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary-light">Audius</a>
            </p>
          </div>
        </GlassPanel>
      </main>

      <BottomPlayer />
      <AuthModal isOpen={showAuth} onClose={() => setShowAuth(false)} />
    </div>
  );
}
