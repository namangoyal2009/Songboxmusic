'use client';

import { useState, useEffect } from 'react';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import TrackList from '@/components/track/TrackList';
import { fetchTrendingTracks } from '@/lib/audius';
import { Track } from '@/types/track';

export default function TrendingPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    async function loadTracks() {
      setLoading(true);
      const data = await fetchTrendingTracks(20);
      setTracks(data);
      setOffset(20);
      setHasMore(data.length === 20);
      setLoading(false);
    }

    loadTracks();
  }, []);

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;

    setLoadingMore(true);
    try {
      const newTracks = await fetchTrendingTracks(20, offset);

      if (newTracks.length === 0) {
        setHasMore(false);
      } else {
        setTracks((prev) => [...prev, ...newTracks]);
        setOffset((prev) => prev + newTracks.length);
        setHasMore(newTracks.length === 20);
      }
    } catch (error) {
      console.error('Error loading more tracks:', error);
    } finally {
      setLoadingMore(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />

      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        <GlassPanel className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Trending Now 🔥
          </h1>
          <p className="text-foreground-secondary">
            Discover the hottest tracks on Audius right now
          </p>
        </GlassPanel>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="bg-white/5 rounded-lg h-72 animate-pulse shimmer"
              />
            ))}
          </div>
        ) : (
          <TrackList
            tracks={tracks}
            columns={4}
            onLoadMore={loadMore}
            hasMore={hasMore}
            isLoading={loadingMore}
          />
        )}
      </main>

      <BottomPlayer />
    </div>
  );
}
