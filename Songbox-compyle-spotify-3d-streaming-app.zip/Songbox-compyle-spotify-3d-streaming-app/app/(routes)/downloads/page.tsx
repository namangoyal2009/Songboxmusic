'use client';

import { useState, useEffect } from 'react';
import { Track } from '@/types/track';
import {
  getAllDownloadedTracks,
  getStorageInfo,
  deleteOfflineTrack,
} from '@/lib/offline-storage';
import TrackCard from '@/components/track/TrackCard';
import GlassPanel from '@/components/ui/GlassPanel';

export default function DownloadsPage() {
  const [downloadedTracks, setDownloadedTracks] = useState<Track[]>([]);
  const [storageInfo, setStorageInfo] = useState({ used: 0, available: 0, total: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDownloadedTracks();
    loadStorageInfo();
  }, []);

  const loadDownloadedTracks = async () => {
    try {
      setLoading(true);
      const tracks = await getAllDownloadedTracks();
      setDownloadedTracks(tracks);
    } catch (error) {
      console.error('Error loading downloaded tracks:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStorageInfo = async () => {
    try {
      const info = await getStorageInfo();
      setStorageInfo(info);
    } catch (error) {
      console.error('Error loading storage info:', error);
    }
  };

  const handleDeleteTrack = async (trackId: string) => {
    try {
      await deleteOfflineTrack(trackId);
      setDownloadedTracks(downloadedTracks.filter((t) => t.id !== trackId));
      loadStorageInfo(); // Refresh storage info
    } catch (error) {
      console.error('Error deleting track:', error);
    }
  };

  const handleClearAll = async () => {
    if (!confirm('Are you sure you want to delete all downloaded tracks?')) {
      return;
    }

    try {
      await Promise.all(downloadedTracks.map((track) => deleteOfflineTrack(track.id)));
      setDownloadedTracks([]);
      loadStorageInfo();
    } catch (error) {
      console.error('Error clearing all downloads:', error);
    }
  };

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const usagePercentage =
    storageInfo.total > 0 ? ((storageInfo.used / storageInfo.total) * 100).toFixed(1) : '0';

  return (
    <div className="min-h-screen pt-20 pb-32 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Downloaded Tracks</h1>
          <p className="text-foreground-secondary">
            Tracks available for offline playback
          </p>
        </div>

        {/* Storage Info */}
        <GlassPanel padding="lg" className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-1">Storage Usage</h2>
              <p className="text-sm text-foreground-secondary">
                {formatBytes(storageInfo.used)} of {formatBytes(storageInfo.total)} used
              </p>
            </div>
            {downloadedTracks.length > 0 && (
              <button
                onClick={handleClearAll}
                className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-500 rounded-lg text-sm font-medium transition-colors"
              >
                Clear All
              </button>
            )}
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500"
              style={{ width: `${usagePercentage}%` }}
            />
          </div>
          <p className="text-xs text-foreground-muted mt-2">{usagePercentage}% used</p>
        </GlassPanel>

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-square bg-white/5 rounded-lg mb-3" />
                <div className="h-4 bg-white/5 rounded mb-2" />
                <div className="h-3 bg-white/5 rounded w-2/3" />
              </div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && downloadedTracks.length === 0 && (
          <GlassPanel padding="xl" className="text-center">
            <div className="flex flex-col items-center justify-center py-12">
              <svg
                className="w-20 h-20 text-foreground-muted mb-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                />
              </svg>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                No Downloaded Tracks
              </h3>
              <p className="text-foreground-secondary mb-6 max-w-md">
                Download tracks for offline playback. Look for the download button on track cards.
              </p>
              <a
                href="/trending"
                className="px-6 py-3 bg-primary hover:bg-primary-dark rounded-lg text-white font-medium transition-colors"
              >
                Browse Tracks
              </a>
            </div>
          </GlassPanel>
        )}

        {/* Downloaded Tracks Grid */}
        {!loading && downloadedTracks.length > 0 && (
          <>
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm text-foreground-secondary">
                {downloadedTracks.length} track{downloadedTracks.length !== 1 ? 's' : ''}{' '}
                downloaded
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {downloadedTracks.map((track) => (
                <TrackCard key={track.id} track={track} playlist={downloadedTracks} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
