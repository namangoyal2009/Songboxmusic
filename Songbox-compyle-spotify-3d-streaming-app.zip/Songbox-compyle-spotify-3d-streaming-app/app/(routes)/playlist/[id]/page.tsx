'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import Button from '@/components/ui/Button';
import TrackList from '@/components/track/TrackList';
import { normalizeAudiusTrack } from '@/lib/audius';
import { Track } from '@/types/track';
import { AudiusPlaylist } from '@/types/audius';
import { useAudioStore } from '@/store/audioStore';

export default function PlaylistPage() {
  const params = useParams();
  const playlistId = params.id as string;
  const [menuOpen, setMenuOpen] = useState(false);
  const [playlist, setPlaylist] = useState<AudiusPlaylist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [displayCount, setDisplayCount] = useState(20);
  const { playTrack } = useAudioStore();

  useEffect(() => {
    async function loadPlaylist() {
      setLoading(true);
      try {
        const response = await fetch(
          `https://discoveryprovider.audius.co/v1/playlists/${playlistId}?app_name=Songbox`
        );
        if (response.ok) {
          const data = await response.json();
          setPlaylist(data.data);
          if (data.data.tracks) {
            const normalizedTracks = data.data.tracks.map(normalizeAudiusTrack);
            setAllTracks(normalizedTracks);
            setTracks(normalizedTracks.slice(0, 20));
          }
        }
      } catch (error) {
        console.error('Error loading playlist:', error);
      } finally {
        setLoading(false);
      }
    }

    loadPlaylist();
  }, [playlistId]);

  const loadMoreTracks = () => {
    const newDisplayCount = displayCount + 20;
    setTracks(allTracks.slice(0, newDisplayCount));
    setDisplayCount(newDisplayCount);
  };

  const handlePlayAll = () => {
    if (allTracks.length > 0) {
      playTrack(allTracks[0], allTracks);
    }
  };

  const handleShuffle = () => {
    if (allTracks.length > 0) {
      const shuffled = [...allTracks].sort(() => Math.random() - 0.5);
      playTrack(shuffled[0], shuffled);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />
      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        {loading ? (
          <GlassPanel className="mb-8">
            <div className="flex items-start gap-6">
              <div className="w-48 h-48 rounded-lg bg-white/5 animate-pulse flex-shrink-0" />
              <div className="flex-1 space-y-3 pt-4">
                <div className="h-8 w-64 bg-white/5 rounded animate-pulse" />
                <div className="h-4 w-48 bg-white/5 rounded animate-pulse" />
                <div className="h-4 w-32 bg-white/5 rounded animate-pulse" />
              </div>
            </div>
          </GlassPanel>
        ) : playlist ? (
          <>
            <GlassPanel className="mb-8">
              <div className="flex flex-col md:flex-row items-start gap-6">
                <div className="w-48 h-48 rounded-lg overflow-hidden bg-gradient-to-br from-primary/30 to-secondary/30 flex-shrink-0">
                  {playlist.artwork?.['480x480'] ? (
                    <img
                      src={playlist.artwork['480x480']}
                      alt={playlist.playlist_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <svg className="w-20 h-20 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                      </svg>
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-foreground-secondary mb-2">
                    {playlist.is_album ? 'Album' : 'Playlist'}
                  </p>
                  <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
                    {playlist.playlist_name}
                  </h1>
                  {playlist.description && (
                    <p className="text-foreground-secondary mb-4 line-clamp-2">
                      {playlist.description}
                    </p>
                  )}
                  <div className="flex items-center gap-2 text-sm text-foreground-secondary mb-6">
                    <span>{playlist.user.name}</span>
                    <span>•</span>
                    <span>{playlist.track_count} tracks</span>
                  </div>
                  <div className="flex gap-3">
                    <Button
                      variant="primary"
                      leftIcon={
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                        </svg>
                      }
                      onClick={handlePlayAll}
                    >
                      Play All
                    </Button>
                    <Button
                      variant="outline"
                      leftIcon={
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                          <path d="M4 3a1 1 0 000 2h1.5L2 8.5a1 1 0 001.5 1.5L7 6.5V8a1 1 0 102 0V4a1 1 0 00-1-1H4zm12 0a1 1 0 000 2h-1.5l3.5 3.5a1 1 0 01-1.5 1.5L13 6.5V8a1 1 0 11-2 0V4a1 1 0 011-1h4z" />
                        </svg>
                      }
                      onClick={handleShuffle}
                    >
                      Shuffle
                    </Button>
                  </div>
                </div>
              </div>
            </GlassPanel>

            <GlassPanel>
              {tracks.length > 0 ? (
                <TrackList
                  tracks={tracks}
                  columns={4}
                  onLoadMore={loadMoreTracks}
                  hasMore={displayCount < allTracks.length}
                  isLoading={false}
                />
              ) : (
                <p className="text-center py-8 text-foreground-secondary">No tracks in this playlist</p>
              )}
            </GlassPanel>
          </>
        ) : (
          <GlassPanel className="text-center py-12">
            <h2 className="text-xl font-semibold text-foreground mb-2">Playlist not found</h2>
            <p className="text-foreground-secondary">The playlist you're looking for doesn't exist</p>
          </GlassPanel>
        )}
      </main>

      <BottomPlayer />
    </div>
  );
}
