'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import SearchBar from '@/components/search/SearchBar';
import SearchResults from '@/components/search/SearchResults';
import SearchFilters, { FilterOptions } from '@/components/search/SearchFilters';
import { searchTracks } from '@/lib/audius';
import { Track } from '@/types/track';
import { AudiusUser, AudiusPlaylist } from '@/types/audius';

export default function SearchPage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [artists, setArtists] = useState<AudiusUser[]>([]);
  const [playlists, setPlaylists] = useState<AudiusPlaylist[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [filters, setFilters] = useState<FilterOptions>({ sortBy: 'relevance', duration: 'any' });
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery);
    }
  }, [initialQuery, filters]);

  const filterTracks = (tracks: Track[]): Track[] => {
    let filtered = [...tracks];

    // Apply duration filter
    if (filters.duration !== 'any') {
      filtered = filtered.filter((track) => {
        const minutes = track.duration / 60;
        switch (filters.duration) {
          case 'short':
            return minutes < 3;
          case 'medium':
            return minutes >= 3 && minutes <= 5;
          case 'long':
            return minutes > 5;
          default:
            return true;
        }
      });
    }

    // Apply sort filter
    switch (filters.sortBy) {
      case 'popularity':
        filtered.sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
        break;
      case 'recent':
        // Audius doesn't provide upload date in search, so we keep the default order
        // In a real implementation, you'd need to fetch additional metadata
        break;
      case 'relevance':
      default:
        // Keep default relevance order from API
        break;
    }

    return filtered;
  };

  const performSearch = async (query: string) => {
    if (!query.trim()) {
      setTracks([]);
      setArtists([]);
      setPlaylists([]);
      return;
    }

    setLoading(true);
    setOffset(0);
    setHasMore(true);
    try {
      // Search tracks
      const trackResults = await searchTracks(query, 20, 0);
      const filteredTracks = filterTracks(trackResults);
      setTracks(filteredTracks);
      setOffset(20);
      setHasMore(trackResults.length === 20);

      // Search artists
      const artistResponse = await fetch(
        `https://discoveryprovider.audius.co/v1/users/search?query=${encodeURIComponent(query)}&app_name=Songbox&limit=20`
      );
      if (artistResponse.ok) {
        const artistData = await artistResponse.json();
        setArtists(artistData.data || []);
      }

      // Search playlists
      const playlistResponse = await fetch(
        `https://discoveryprovider.audius.co/v1/playlists/search?query=${encodeURIComponent(query)}&app_name=Songbox&limit=20`
      );
      if (playlistResponse.ok) {
        const playlistData = await playlistResponse.json();
        setPlaylists(playlistData.data || []);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMoreTracks = async () => {
    if (loadingMore || !hasMore || !initialQuery) return;

    setLoadingMore(true);
    try {
      const newTracks = await searchTracks(initialQuery, 20, offset);

      if (newTracks.length === 0) {
        setHasMore(false);
      } else {
        const filteredNewTracks = filterTracks(newTracks);
        setTracks((prev) => [...prev, ...filteredNewTracks]);
        setOffset((prev) => prev + newTracks.length);
        setHasMore(newTracks.length === 20);
      }
    } catch (error) {
      console.error('Error loading more tracks:', error);
    } finally {
      setLoadingMore(false);
    }
  };

  const handleFilterChange = (newFilters: FilterOptions) => {
    setFilters(newFilters);
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />
      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        <GlassPanel className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">Search</h1>
          <SearchBar onSearch={performSearch} autoFocus={!initialQuery} />
          {initialQuery && (
            <div className="mt-4 pt-4 border-t border-white/10">
              <SearchFilters onFilterChange={handleFilterChange} />
            </div>
          )}
        </GlassPanel>

        {initialQuery && (
          <GlassPanel>
            <SearchResults
              tracks={tracks}
              artists={artists}
              playlists={playlists}
              loading={loading}
              onLoadMoreTracks={loadMoreTracks}
              hasMoreTracks={hasMore}
              isLoadingMoreTracks={loadingMore}
            />
          </GlassPanel>
        )}

        {!initialQuery && !loading && (
          <GlassPanel className="text-center py-12">
            <svg className="w-16 h-16 mx-auto mb-4 text-foreground-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Search for music
            </h2>
            <p className="text-foreground-secondary">
              Find your favorite songs, artists, and playlists
            </p>
          </GlassPanel>
        )}
      </main>

      <BottomPlayer />
    </div>
  );
}
