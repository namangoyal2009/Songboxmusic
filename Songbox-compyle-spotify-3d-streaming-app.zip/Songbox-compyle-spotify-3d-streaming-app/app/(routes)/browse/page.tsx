'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import Card from '@/components/ui/Card';

const GENRES = [
  { name: 'Electronic', color: 'from-purple-500 to-pink-500', emoji: '🎹' },
  { name: 'Hip-Hop', color: 'from-orange-500 to-red-500', emoji: '🎤' },
  { name: 'Rock', color: 'from-gray-500 to-slate-700', emoji: '🎸' },
  { name: 'Pop', color: 'from-pink-500 to-rose-500', emoji: '🎵' },
  { name: 'Jazz', color: 'from-blue-500 to-cyan-500', emoji: '🎷' },
  { name: 'Classical', color: 'from-indigo-500 to-purple-500', emoji: '🎻' },
  { name: 'R&B', color: 'from-red-500 to-pink-500', emoji: '💜' },
  { name: 'Country', color: 'from-yellow-500 to-orange-500', emoji: '🤠' },
  { name: 'Latin', color: 'from-red-500 to-yellow-500', emoji: '💃' },
  { name: 'Reggae', color: 'from-green-500 to-yellow-500', emoji: '🌴' },
  { name: 'Metal', color: 'from-gray-700 to-black', emoji: '🤘' },
  { name: 'Folk', color: 'from-green-500 to-teal-500', emoji: '🌾' },
];

const MOODS = [
  { name: 'Energetic', color: 'from-red-500 to-orange-500', emoji: '⚡' },
  { name: 'Chill', color: 'from-blue-500 to-purple-500', emoji: '😌' },
  { name: 'Happy', color: 'from-yellow-500 to-green-500', emoji: '😊' },
  { name: 'Focus', color: 'from-indigo-500 to-purple-500', emoji: '🎯' },
  { name: 'Party', color: 'from-pink-500 to-red-500', emoji: '🎉' },
  { name: 'Workout', color: 'from-orange-500 to-red-500', emoji: '💪' },
  { name: 'Sleep', color: 'from-indigo-900 to-purple-900', emoji: '😴' },
  { name: 'Romantic', color: 'from-pink-500 to-rose-500', emoji: '💖' },
];

export default function BrowsePage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  const handleGenreClick = (genre: string) => {
    router.push(`/search?q=${encodeURIComponent(genre)}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />
      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        <GlassPanel className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Browse Music</h1>
          <p className="text-foreground-secondary">
            Discover music by genre or mood
          </p>
        </GlassPanel>

        {/* Genres */}
        <GlassPanel className="mb-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Genres</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {GENRES.map((genre) => (
              <Card
                key={genre.name}
                hover
                padding="none"
                className="cursor-pointer group overflow-hidden"
                onClick={() => handleGenreClick(genre.name)}
              >
                <div className={`bg-gradient-to-br ${genre.color} p-6 aspect-square flex flex-col items-center justify-center text-white relative overflow-hidden`}>
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                  <div className="text-5xl mb-2 relative z-10 transform group-hover:scale-110 transition-transform">
                    {genre.emoji}
                  </div>
                  <span className="font-bold text-lg relative z-10">{genre.name}</span>
                </div>
              </Card>
            ))}
          </div>
        </GlassPanel>

        {/* Moods */}
        <GlassPanel>
          <h2 className="text-2xl font-bold text-foreground mb-6">Moods</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {MOODS.map((mood) => (
              <Card
                key={mood.name}
                hover
                padding="lg"
                className="cursor-pointer group"
                onClick={() => handleGenreClick(mood.name)}
              >
                <div className={`bg-gradient-to-br ${mood.color} rounded-lg p-4 mb-3 flex items-center justify-center aspect-video`}>
                  <div className="text-5xl transform group-hover:scale-110 transition-transform">
                    {mood.emoji}
                  </div>
                </div>
                <h3 className="font-semibold text-foreground text-center group-hover:text-primary transition-colors">
                  {mood.name}
                </h3>
              </Card>
            ))}
          </div>
        </GlassPanel>
      </main>

      <BottomPlayer />
    </div>
  );
}
