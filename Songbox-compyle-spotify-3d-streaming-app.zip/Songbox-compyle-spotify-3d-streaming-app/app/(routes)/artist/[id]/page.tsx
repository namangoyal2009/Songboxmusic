'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import TopBar from '@/components/layout/TopBar';
import SideMenu from '@/components/layout/SideMenu';
import BottomPlayer from '@/components/layout/BottomPlayer';
import VisualizerCanvas from '@/components/visualizers/VisualizerCanvas';
import GlassPanel from '@/components/ui/GlassPanel';
import TrackList from '@/components/track/TrackList';
import { fetchUserTracks } from '@/lib/audius';
import { Track } from '@/types/track';
import { AudiusUser } from '@/types/audius';
import { formatNumber } from '@/lib/utils';

export default function ArtistPage() {
  const params = useParams();
  const artistId = params.id as string;
  const [menuOpen, setMenuOpen] = useState(false);
  const [artist, setArtist] = useState<AudiusUser | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    async function loadArtist() {
      setLoading(true);
      try {
        // Fetch artist info
        const artistResponse = await fetch(
          `https://discoveryprovider.audius.co/v1/users/${artistId}?app_name=Songbox`
        );
        if (artistResponse.ok) {
          const artistData = await artistResponse.json();
          setArtist(artistData.data);
        }

        // Fetch artist tracks
        const trackData = await fetchUserTracks(artistId, 20, 0);
        setTracks(trackData);
        setOffset(20);
        setHasMore(trackData.length === 20);
      } catch (error) {
        console.error('Error loading artist:', error);
      } finally {
        setLoading(false);
      }
    }

    loadArtist();
  }, [artistId]);

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;

    setLoadingMore(true);
    try {
      const newTracks = await fetchUserTracks(artistId, 20, offset);

      if (newTracks.length === 0) {
        setHasMore(false);
      } else {
        setTracks((prev) => [...prev, ...newTracks]);
        setOffset((prev) => prev + newTracks.length);
        setHasMore(newTracks.length === 20);
      }
    } catch (error) {
      console.error('Error loading more tracks:', error);
    } finally {
      setLoadingMore(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <VisualizerCanvas />
      <TopBar onMenuToggle={() => setMenuOpen(true)} />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="pt-20 pb-24 px-4 md:px-8 max-w-7xl mx-auto">
        {loading ? (
          <GlassPanel className="mb-8">
            <div className="flex items-center gap-6">
              <div className="w-32 h-32 rounded-full bg-white/5 animate-pulse" />
              <div className="flex-1 space-y-3">
                <div className="h-8 w-48 bg-white/5 rounded animate-pulse" />
                <div className="h-4 w-32 bg-white/5 rounded animate-pulse" />
              </div>
            </div>
          </GlassPanel>
        ) : artist ? (
          <>
            <GlassPanel className="mb-8">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <div className="w-32 h-32 rounded-full overflow-hidden bg-gradient-to-br from-primary/30 to-secondary/30 flex-shrink-0">
                  {artist.profile_picture?.['480x480'] ? (
                    <img
                      src={artist.profile_picture['480x480']}
                      alt={artist.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl text-white">
                      {artist.name[0]}
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                      {artist.name}
                    </h1>
                    {artist.is_verified && (
                      <svg className="w-6 h-6 text-primary" fill="currentColor" viewBox="0 0 20 20">
                        <path
                          fillRule="evenodd"
                          d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                    )}
                  </div>
                  <p className="text-sm text-foreground-secondary mb-4">
                    @{artist.handle}
                  </p>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <span className="text-foreground">
                      <strong>{formatNumber(artist.follower_count)}</strong> followers
                    </span>
                    <span className="text-foreground-secondary">•</span>
                    <span className="text-foreground">
                      <strong>{formatNumber(artist.track_count)}</strong> tracks
                    </span>
                  </div>
                  {artist.bio && (
                    <p className="mt-4 text-foreground-secondary line-clamp-3">
                      {artist.bio}
                    </p>
                  )}
                </div>
              </div>
            </GlassPanel>

            <GlassPanel>
              <h2 className="text-2xl font-bold text-foreground mb-6">Top Tracks</h2>
              {tracks.length > 0 ? (
                <TrackList
                  tracks={tracks}
                  columns={5}
                  onLoadMore={loadMore}
                  hasMore={hasMore}
                  isLoading={loadingMore}
                />
              ) : (
                <p className="text-center py-8 text-foreground-secondary">No tracks found</p>
              )}
            </GlassPanel>
          </>
        ) : (
          <GlassPanel className="text-center py-12">
            <h2 className="text-xl font-semibold text-foreground mb-2">Artist not found</h2>
            <p className="text-foreground-secondary">The artist you're looking for doesn't exist</p>
          </GlassPanel>
        )}
      </main>

      <BottomPlayer />
    </div>
  );
}
