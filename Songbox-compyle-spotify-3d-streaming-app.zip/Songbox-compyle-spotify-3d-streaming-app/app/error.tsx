'use client';

import { useEffect } from 'react';
import GlassPanel from '@/components/ui/GlassPanel';
import Button from '@/components/ui/Button';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('Application error:', error);
  }, [error]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <GlassPanel padding="xl" className="max-w-md text-center">
        <div className="inline-block p-6 rounded-full bg-error/10 mb-6">
          <svg
            className="w-16 h-16 text-error"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>
        </div>

        <h1 className="text-3xl font-bold text-foreground mb-3">Something went wrong</h1>

        <p className="text-foreground-secondary mb-6">
          An unexpected error occurred. Don't worry, we've logged it and will look into it.
        </p>

        {process.env.NODE_ENV === 'development' && (
          <div className="mb-6 p-4 bg-white/5 rounded-lg text-left">
            <p className="text-xs text-error font-mono">{error.message}</p>
          </div>
        )}

        <div className="flex flex-col gap-3">
          <Button variant="primary" onClick={reset} className="w-full">
            Try Again
          </Button>

          <Button
            variant="outline"
            onClick={() => (window.location.href = '/')}
            className="w-full"
          >
            Go to Home
          </Button>
        </div>

        {error.digest && (
          <p className="mt-6 text-xs text-foreground-muted">Error ID: {error.digest}</p>
        )}
      </GlassPanel>
    </div>
  );
}
