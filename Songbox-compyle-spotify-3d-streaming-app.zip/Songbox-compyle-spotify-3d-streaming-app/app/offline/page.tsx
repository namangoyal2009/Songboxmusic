'use client';

import GlassPanel from '@/components/ui/GlassPanel';
import Link from 'next/link';

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <GlassPanel padding="xl" className="max-w-md text-center">
        <div className="inline-block p-6 rounded-full bg-warning/10 mb-6">
          <svg
            className="w-16 h-16 text-warning"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M18.364 5.636a9 9 0 010 12.728m0 0l-2.829-2.829m2.829 2.829L21 21M15.536 8.464a5 5 0 010 7.072m0 0l-2.829-2.829m-4.243 2.829a4.978 4.978 0 01-1.414-2.83m-1.414 5.658a9 9 0 01-2.167-9.238m7.824 2.167a1 1 0 111.414 1.414m-1.414-1.414L3 3m8.293 8.293l1.414 1.414"
            />
          </svg>
        </div>

        <h1 className="text-3xl font-bold text-foreground mb-3">You're Offline</h1>

        <p className="text-foreground-secondary mb-6">
          No internet connection detected. Some features may be unavailable, but you can still
          play your downloaded tracks.
        </p>

        <div className="flex flex-col gap-3">
          <Link
            href="/downloads"
            className="w-full px-6 py-3 bg-primary hover:bg-primary-dark rounded-lg text-white font-medium transition-colors"
          >
            View Downloaded Tracks
          </Link>

          <button
            onClick={() => window.location.reload()}
            className="w-full px-6 py-3 bg-white/5 hover:bg-white/10 rounded-lg text-foreground font-medium transition-colors"
          >
            Try Again
          </button>

          <Link
            href="/"
            className="text-primary hover:text-primary-light text-sm font-medium"
          >
            Go to Home
          </Link>
        </div>

        <div className="mt-8 p-4 bg-white/5 rounded-lg">
          <p className="text-xs text-foreground-muted">
            💡 Tip: Download tracks for offline playback when you have an internet connection
          </p>
        </div>
      </GlassPanel>
    </div>
  );
}
