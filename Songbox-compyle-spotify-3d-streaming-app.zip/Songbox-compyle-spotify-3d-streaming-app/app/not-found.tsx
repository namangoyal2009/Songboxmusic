import GlassPanel from '@/components/ui/GlassPanel';
import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <GlassPanel padding="xl" className="max-w-md text-center">
        <div className="inline-block p-6 rounded-full bg-primary/10 mb-6">
          <svg
            className="w-16 h-16 text-primary"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
        </div>

        <h1 className="text-6xl font-bold text-foreground mb-3">404</h1>
        <h2 className="text-2xl font-semibold text-foreground mb-3">Page Not Found</h2>

        <p className="text-foreground-secondary mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>

        <div className="flex flex-col gap-3">
          <Link
            href="/"
            className="w-full px-6 py-3 bg-primary hover:bg-primary-dark rounded-lg text-white font-medium transition-colors text-center"
          >
            Back to Home
          </Link>

          <Link
            href="/search"
            className="w-full px-6 py-3 bg-white/5 hover:bg-white/10 rounded-lg text-foreground font-medium transition-colors text-center"
          >
            Search Tracks
          </Link>
        </div>
      </GlassPanel>
    </div>
  );
}
