import { Track } from '@/types/track';

const DB_NAME = 'songbox-offline';
const DB_VERSION = 1;
const STORE_NAME = 'tracks';
const AUDIO_STORE = 'audio-blobs';

interface OfflineTrack {
  track: Track;
  downloadedAt: string;
  audioBlob: Blob;
}

// Initialize IndexedDB
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Create tracks store
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'track.id' });
        store.createIndex('downloadedAt', 'downloadedAt', { unique: false });
      }

      // Create audio blobs store
      if (!db.objectStoreNames.contains(AUDIO_STORE)) {
        db.createObjectStore(AUDIO_STORE, { keyPath: 'trackId' });
      }
    };
  });
}

// Download track for offline playback
export async function downloadTrackOffline(track: Track): Promise<void> {
  try {
    // Fetch audio from stream URL
    const response = await fetch(track.streamUrl);
    if (!response.ok) throw new Error('Failed to fetch audio');

    const audioBlob = await response.blob();

    // Save to IndexedDB
    const db = await openDB();
    const tx = db.transaction([STORE_NAME, AUDIO_STORE], 'readwrite');

    const trackStore = tx.objectStore(STORE_NAME);
    const audioStore = tx.objectStore(AUDIO_STORE);

    const offlineTrack: Omit<OfflineTrack, 'audioBlob'> = {
      track,
      downloadedAt: new Date().toISOString(),
    };

    await Promise.all([
      new Promise((resolve, reject) => {
        const req = trackStore.put(offlineTrack);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      }),
      new Promise((resolve, reject) => {
        const req = audioStore.put({ trackId: track.id, blob: audioBlob });
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      }),
    ]);

    await new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve(undefined);
      tx.onerror = () => reject(tx.error);
    });

    console.log(`Downloaded track: ${track.title}`);
  } catch (error) {
    console.error('Error downloading track:', error);
    throw error;
  }
}

// Check if track is downloaded
export async function isTrackDownloaded(trackId: string): Promise<boolean> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);

    return new Promise((resolve, reject) => {
      const request = store.get(trackId);
      request.onsuccess = () => resolve(!!request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error checking download status:', error);
    return false;
  }
}

// Get offline track with audio blob
export async function getOfflineTrack(trackId: string): Promise<OfflineTrack | null> {
  try {
    const db = await openDB();
    const tx = db.transaction([STORE_NAME, AUDIO_STORE], 'readonly');
    const trackStore = tx.objectStore(STORE_NAME);
    const audioStore = tx.objectStore(AUDIO_STORE);

    const trackData = await new Promise<Omit<OfflineTrack, 'audioBlob'> | null>((resolve, reject) => {
      const req = trackStore.get(trackId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (!trackData) return null;

    const audioData = await new Promise<{ trackId: string; blob: Blob } | null>((resolve, reject) => {
      const req = audioStore.get(trackId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (!audioData) return null;

    return {
      ...trackData,
      audioBlob: audioData.blob,
    };
  } catch (error) {
    console.error('Error getting offline track:', error);
    return null;
  }
}

// Get all downloaded tracks
export async function getAllDownloadedTracks(): Promise<Track[]> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        const results = request.result as Omit<OfflineTrack, 'audioBlob'>[];
        resolve(results.map((r) => r.track));
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error getting downloaded tracks:', error);
    return [];
  }
}

// Delete offline track
export async function deleteOfflineTrack(trackId: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction([STORE_NAME, AUDIO_STORE], 'readwrite');
    const trackStore = tx.objectStore(STORE_NAME);
    const audioStore = tx.objectStore(AUDIO_STORE);

    await Promise.all([
      new Promise<void>((resolve, reject) => {
        const req = trackStore.delete(trackId);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      }),
      new Promise<void>((resolve, reject) => {
        const req = audioStore.delete(trackId);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
      }),
    ]);

    console.log(`Deleted offline track: ${trackId}`);
  } catch (error) {
    console.error('Error deleting offline track:', error);
    throw error;
  }
}

// Get total storage used
export async function getStorageInfo(): Promise<{ used: number; available: number; total: number }> {
  try {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      return {
        used: estimate.usage || 0,
        available: (estimate.quota || 0) - (estimate.usage || 0),
        total: estimate.quota || 0,
      };
    }
    return { used: 0, available: 0, total: 0 };
  } catch (error) {
    console.error('Error getting storage info:', error);
    return { used: 0, available: 0, total: 0 };
  }
}

// Create object URL from offline track
export function createOfflineTrackURL(audioBlob: Blob): string {
  return URL.createObjectURL(audioBlob);
}

// Revoke object URL
export function revokeOfflineTrackURL(url: string): void {
  URL.revokeObjectURL(url);
}
