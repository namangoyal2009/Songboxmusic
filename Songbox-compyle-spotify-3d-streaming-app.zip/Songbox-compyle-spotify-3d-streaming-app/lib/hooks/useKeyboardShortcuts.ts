'use client';

import { useEffect } from 'react';
import { useAudioStore } from '@/store/audioStore';

export function useKeyboardShortcuts() {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable
      ) {
        return;
      }

      const {
        togglePlay,
        playNext,
        playPrevious,
        seekTo,
        setVolume,
        volume,
        currentTime,
        setRepeat,
        repeat,
        toggleShuffle,
      } = useAudioStore.getState();

      switch (e.key.toLowerCase()) {
        case ' ': // Space - Play/Pause
          e.preventDefault();
          togglePlay();
          break;

        case 'arrowright': // Right arrow - Skip forward 10s
          e.preventDefault();
          seekTo(currentTime + 10);
          break;

        case 'arrowleft': // Left arrow - Skip back 10s
          e.preventDefault();
          seekTo(Math.max(0, currentTime - 10));
          break;

        case 'arrowup': // Up arrow - Volume up
          e.preventDefault();
          setVolume(Math.min(1, volume + 0.1));
          break;

        case 'arrowdown': // Down arrow - Volume down
          e.preventDefault();
          setVolume(Math.max(0, volume - 0.1));
          break;

        case 'n': // N - Next track
          e.preventDefault();
          playNext();
          break;

        case 'p': // P - Previous track
          e.preventDefault();
          playPrevious();
          break;

        case 's': // S - Toggle shuffle
          e.preventDefault();
          toggleShuffle();
          break;

        case 'r': // R - Toggle repeat
          e.preventDefault();
          const modes: Array<typeof repeat> = ['off', 'one', 'all'];
          const currentIndex = modes.indexOf(repeat);
          const nextMode = modes[(currentIndex + 1) % modes.length];
          setRepeat(nextMode);
          break;

        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);
}
