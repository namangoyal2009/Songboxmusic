import {
  AudiusTrack,
  AudiusUser,
  AudiusPlaylist,
  AudiusTrendingResponse,
  AudiusSearchResponse,
  AUDIUS_API_BASE,
  AUDIUS_ENDPOINTS,
  getStreamUrl,
} from '@/types/audius';
import { Track, genreToMood } from '@/types/track';

const APP_NAME = 'Songbox';

// Helper to convert Audius track to internal Track format
export function normalizeAudiusTrack(audiusTrack: AudiusTrack): Track {
  // Prefer highest quality artwork
  const artwork =
    audiusTrack.artwork?.['1000x1000'] ||
    audiusTrack.artwork?.['480x480'] ||
    audiusTrack.artwork?.['150x150'] ||
    '';

  return {
    id: audiusTrack.id,
    title: audiusTrack.title,
    artist: audiusTrack.user.name,
    artistId: audiusTrack.user.id,
    artwork,
    duration: audiusTrack.duration,
    streamUrl: getStreamUrl(audiusTrack.id),
    genre: audiusTrack.genre || 'Unknown',
    mood: genreToMood(audiusTrack.genre || ''),
    playCount: audiusTrack.play_count,
    releaseDate: audiusTrack.release_date,
    description: audiusTrack.description,
    downloadable: audiusTrack.downloadable || false,
  };
}

// Fetch complete track metadata by ID (for enhanced details)
export async function fetchTrackMetadata(trackId: string): Promise<Track | null> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.track(trackId)}?app_name=${APP_NAME}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch track metadata: ${response.statusText}`);
    }

    const data = await response.json();
    return normalizeAudiusTrack(data.data);
  } catch (error) {
    console.error('Error fetching track metadata:', error);
    return null;
  }
}

// Fetch trending tracks
export async function fetchTrendingTracks(
  limit: number = 20,
  offset: number = 0
): Promise<Track[]> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.trending}?app_name=${APP_NAME}&limit=${limit}&offset=${offset}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch trending tracks: ${response.statusText}`);
    }

    const data: AudiusTrendingResponse = await response.json();
    return data.data.map(normalizeAudiusTrack);
  } catch (error) {
    console.error('Error fetching trending tracks:', error);
    return [];
  }
}

// Search tracks
export async function searchTracks(
  query: string,
  limit: number = 20,
  offset: number = 0
): Promise<Track[]> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.searchTracks}?query=${encodeURIComponent(query)}&app_name=${APP_NAME}&limit=${limit}&offset=${offset}`
    );

    if (!response.ok) {
      throw new Error(`Failed to search tracks: ${response.statusText}`);
    }

    const data: AudiusSearchResponse<AudiusTrack> = await response.json();
    return data.data.map(normalizeAudiusTrack);
  } catch (error) {
    console.error('Error searching tracks:', error);
    return [];
  }
}

// Fetch track by ID
export async function fetchTrackById(trackId: string): Promise<Track | null> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.track(trackId)}?app_name=${APP_NAME}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch track: ${response.statusText}`);
    }

    const data = await response.json();
    return normalizeAudiusTrack(data.data);
  } catch (error) {
    console.error('Error fetching track:', error);
    return null;
  }
}

// Fetch tracks by genre
export async function fetchTracksByGenre(
  genre: string,
  limit: number = 20
): Promise<Track[]> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.searchTracks}?query=${encodeURIComponent(genre)}&app_name=${APP_NAME}&limit=${limit}`
    );

    if (!response.ok) {
      return [];
    }

    const data: AudiusSearchResponse<AudiusTrack> = await response.json();
    return data.data
      .filter((track) => track.genre?.toLowerCase().includes(genre.toLowerCase()))
      .map(normalizeAudiusTrack);
  } catch (error) {
    console.error('Error fetching tracks by genre:', error);
    return [];
  }
}

// Fetch user tracks (artist tracks)
export async function fetchUserTracks(
  userId: string,
  limit: number = 20,
  offset: number = 0
): Promise<Track[]> {
  try {
    const response = await fetch(
      `${AUDIUS_ENDPOINTS.userTracks(userId)}?app_name=${APP_NAME}&limit=${limit}&offset=${offset}`
    );

    if (!response.ok) {
      return [];
    }

    const data: AudiusSearchResponse<AudiusTrack> = await response.json();
    return data.data.map(normalizeAudiusTrack);
  } catch (error) {
    console.error('Error fetching user tracks:', error);
    return [];
  }
}
