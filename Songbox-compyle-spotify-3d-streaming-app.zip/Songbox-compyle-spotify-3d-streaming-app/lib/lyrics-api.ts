// Lyrics API Integration with caching
// Primary: Lyrics.ovh (free, no auth)
// Backup: Musixmatch (requires API key)

const DB_NAME = 'songbox-lyrics';
const DB_VERSION = 1;
const STORE_NAME = 'lyrics-cache';

interface CachedLyrics {
  trackId: string;
  artist: string;
  title: string;
  lyrics: string;
  source: 'lyrics.ovh' | 'musixmatch' | 'not_found';
  cachedAt: string;
}

// Initialize IndexedDB for lyrics caching
function openLyricsDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'trackId' });
        store.createIndex('cachedAt', 'cachedAt', { unique: false });
      }
    };
  });
}

// Fetch lyrics from Lyrics.ovh
async function fetchFromLyricsOvh(artist: string, title: string): Promise<string | null> {
  try {
    const response = await fetch(
      `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`
    );

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    return data.lyrics || null;
  } catch (error) {
    console.error('Lyrics.ovh error:', error);
    return null;
  }
}

// Fetch lyrics from Musixmatch (backup)
async function fetchFromMusixmatch(artist: string, title: string): Promise<string | null> {
  const apiKey = process.env.NEXT_PUBLIC_MUSIXMATCH_API_KEY;

  if (!apiKey) {
    return null; // No API key configured
  }

  try {
    // First, search for the track
    const searchResponse = await fetch(
      `https://api.musixmatch.com/ws/1.1/track.search?` +
        `q_artist=${encodeURIComponent(artist)}&` +
        `q_track=${encodeURIComponent(title)}&` +
        `apikey=${apiKey}`
    );

    if (!searchResponse.ok) {
      return null;
    }

    const searchData = await searchResponse.json();
    const trackList = searchData.message?.body?.track_list;

    if (!trackList || trackList.length === 0) {
      return null;
    }

    const trackId = trackList[0].track.track_id;

    // Then, fetch the lyrics
    const lyricsResponse = await fetch(
      `https://api.musixmatch.com/ws/1.1/track.lyrics.get?track_id=${trackId}&apikey=${apiKey}`
    );

    if (!lyricsResponse.ok) {
      return null;
    }

    const lyricsData = await lyricsResponse.json();
    const lyricsBody = lyricsData.message?.body?.lyrics?.lyrics_body;

    return lyricsBody || null;
  } catch (error) {
    console.error('Musixmatch error:', error);
    return null;
  }
}

// Get lyrics from cache
async function getLyricsFromCache(trackId: string): Promise<CachedLyrics | null> {
  try {
    const db = await openLyricsDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);

    return new Promise((resolve, reject) => {
      const request = store.get(trackId);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error getting lyrics from cache:', error);
    return null;
  }
}

// Save lyrics to cache
async function saveLyricsToCache(cachedLyrics: CachedLyrics): Promise<void> {
  try {
    const db = await openLyricsDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    await new Promise<void>((resolve, reject) => {
      const request = store.put(cachedLyrics);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error saving lyrics to cache:', error);
  }
}

// Main function to fetch lyrics (with caching)
export async function fetchLyrics(
  trackId: string,
  artist: string,
  title: string
): Promise<{ lyrics: string | null; source: string }> {
  // Check cache first
  const cached = await getLyricsFromCache(trackId);

  if (cached) {
    // Cache hit - return cached lyrics
    console.log(`Lyrics cache hit for: ${artist} - ${title}`);
    return {
      lyrics: cached.lyrics || null,
      source: `${cached.source} (cached)`,
    };
  }

  // Cache miss - fetch from APIs
  console.log(`Fetching lyrics for: ${artist} - ${title}`);

  // Try Lyrics.ovh first
  let lyrics = await fetchFromLyricsOvh(artist, title);
  let source: 'lyrics.ovh' | 'musixmatch' | 'not_found' = 'lyrics.ovh';

  // If Lyrics.ovh fails, try Musixmatch
  if (!lyrics) {
    lyrics = await fetchFromMusixmatch(artist, title);
    source = lyrics ? 'musixmatch' : 'not_found';
  }

  // Cache the result (even if not found, to avoid repeat requests)
  const cachedLyrics: CachedLyrics = {
    trackId,
    artist,
    title,
    lyrics: lyrics || '',
    source,
    cachedAt: new Date().toISOString(),
  };

  await saveLyricsToCache(cachedLyrics);

  return {
    lyrics,
    source: lyrics ? source : 'not_found',
  };
}

// Get count of cached lyrics
export async function getCachedLyricsCount(): Promise<number> {
  try {
    const db = await openLyricsDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);

    return new Promise((resolve, reject) => {
      const request = store.count();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error getting cached lyrics count:', error);
    return 0;
  }
}

// Clear all cached lyrics
export async function clearLyricsCache(): Promise<void> {
  try {
    const db = await openLyricsDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    await new Promise<void>((resolve, reject) => {
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });

    console.log('Lyrics cache cleared');
  } catch (error) {
    console.error('Error clearing lyrics cache:', error);
  }
}

// Clean up old cached lyrics (older than 30 days)
export async function cleanupOldLyrics(): Promise<void> {
  try {
    const db = await openLyricsDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const index = store.index('cachedAt');

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const range = IDBKeyRange.upperBound(thirtyDaysAgo.toISOString());

    return new Promise((resolve, reject) => {
      const request = index.openCursor(range);
      let deletedCount = 0;

      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          cursor.delete();
          deletedCount++;
          cursor.continue();
        } else {
          console.log(`Cleaned up ${deletedCount} old lyrics entries`);
          resolve();
        }
      };

      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error('Error cleaning up old lyrics:', error);
  }
}
