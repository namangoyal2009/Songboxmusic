import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface DbUser {
  id: string;
  email: string;
  username: string | null;
  avatar_url: string | null;
  created_at: string;
  preferences: {
    theme: 'light' | 'dark';
    visualizerMode: 'particle' | 'wave' | 'shapes' | 'auto';
    vibeMode: boolean;
    volume: number;
  };
}

export interface DbPlaylist {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  cover_image_url: string | null;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

export interface DbPlaylistTrack {
  id: string;
  playlist_id: string;
  audius_track_id: string;
  position: number;
  added_at: string;
}

export interface DbLikedSong {
  id: string;
  user_id: string;
  audius_track_id: string;
  liked_at: string;
}

export interface DbListeningHistory {
  id: string;
  user_id: string | null;
  audius_track_id: string;
  played_at: string;
  duration_seconds: number;
}
