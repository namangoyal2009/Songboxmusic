import { Howl, Howler } from 'howler';
import { Track } from '@/types/track';
import { getOfflineTrack, createOfflineTrackURL, revokeOfflineTrackURL } from './offline-storage';

export class AudioEngine {
  private howl: Howl | null = null;
  private analyser: AnalyserNode | null = null;
  private audioContext: AudioContext | null = null;
  private currentTrack: Track | null = null;
  private offlineAudioURL: string | null = null;

  // Callbacks
  public onPlay?: () => void;
  public onPause?: () => void;
  public onEnd?: () => void;
  public onLoad?: () => void;
  public onSeek?: () => void;
  public onError?: (error: any) => void;
  public onTimeUpdate?: (currentTime: number) => void;

  private timeUpdateInterval: NodeJS.Timeout | null = null;

  constructor() {
    // Initialize Howler global volume
    Howler.volume(0.7);
  }

  // Load and prepare a track (with offline support)
  public async load(track: Track): Promise<void> {
    // Unload previous track
    this.unload();

    this.currentTrack = track;

    // Try to load from offline storage first
    const offlineTrack = await getOfflineTrack(track.id);
    let audioSrc: string;

    if (offlineTrack) {
      // Use offline audio
      this.offlineAudioURL = createOfflineTrackURL(offlineTrack.audioBlob);
      audioSrc = this.offlineAudioURL;
      console.log('Playing from offline storage:', track.title);
    } else {
      // Stream from Audius
      audioSrc = track.streamUrl;
    }

    this.howl = new Howl({
      src: [audioSrc],
      html5: true, // Use HTML5 Audio for streaming
      format: ['mp3', 'aac'],
      onplay: () => {
        this.startTimeUpdates();
        this.updateMediaSession();
        this.onPlay?.();
      },
      onpause: () => {
        this.stopTimeUpdates();
        this.onPause?.();
      },
      onend: () => {
        this.stopTimeUpdates();
        this.onEnd?.();
      },
      onload: () => {
        this.setupAudioAnalyser();
        this.onLoad?.();
      },
      onseek: () => {
        this.onSeek?.();
      },
      onerror: (id, error) => {
        console.error('Howler error:', error);
        this.onError?.(error);
      },
    });
  }

  // Update Media Session API for background playback controls
  private updateMediaSession(): void {
    if (typeof window === 'undefined' || !('mediaSession' in navigator) || !this.currentTrack) {
      return;
    }

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: this.currentTrack.title,
        artist: this.currentTrack.artist,
        album: this.currentTrack.genre || 'Songbox',
        artwork: this.currentTrack.artwork
          ? [
              { src: this.currentTrack.artwork, sizes: '96x96', type: 'image/jpeg' },
              { src: this.currentTrack.artwork, sizes: '128x128', type: 'image/jpeg' },
              { src: this.currentTrack.artwork, sizes: '192x192', type: 'image/jpeg' },
              { src: this.currentTrack.artwork, sizes: '256x256', type: 'image/jpeg' },
              { src: this.currentTrack.artwork, sizes: '384x384', type: 'image/jpeg' },
              { src: this.currentTrack.artwork, sizes: '512x512', type: 'image/jpeg' },
            ]
          : [],
      });

      // Set up action handlers (will be connected from audioStore)
      navigator.mediaSession.setActionHandler('play', () => {
        this.play();
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        this.pause();
      });

      navigator.mediaSession.setActionHandler('seekbackward', () => {
        this.seek(Math.max(0, this.getCurrentTime() - 10));
      });

      navigator.mediaSession.setActionHandler('seekforward', () => {
        this.seek(Math.min(this.getDuration(), this.getCurrentTime() + 10));
      });

      navigator.mediaSession.setActionHandler('previoustrack', () => {
        // Will be handled by audioStore
      });

      navigator.mediaSession.setActionHandler('nexttrack', () => {
        // Will be handled by audioStore
      });
    } catch (error) {
      console.error('Error updating Media Session:', error);
    }
  }

  // Play
  public play(): void {
    if (this.howl) {
      this.howl.play();
    }
  }

  // Pause
  public pause(): void {
    if (this.howl) {
      this.howl.pause();
    }
  }

  // Toggle play/pause
  public togglePlay(): void {
    if (this.howl) {
      if (this.howl.playing()) {
        this.pause();
      } else {
        this.play();
      }
    }
  }

  // Stop
  public stop(): void {
    if (this.howl) {
      this.howl.stop();
      this.stopTimeUpdates();
    }
  }

  // Seek to position (in seconds)
  public seek(seconds: number): void {
    if (this.howl) {
      this.howl.seek(seconds);
    }
  }

  // Get current seek position
  public getCurrentTime(): number {
    if (this.howl) {
      return this.howl.seek() as number;
    }
    return 0;
  }

  // Get duration
  public getDuration(): number {
    if (this.howl) {
      return this.howl.duration();
    }
    return 0;
  }

  // Check if playing
  public isPlaying(): boolean {
    return this.howl?.playing() ?? false;
  }

  // Set volume (0-1)
  public setVolume(volume: number): void {
    Howler.volume(Math.max(0, Math.min(1, volume)));
  }

  // Get volume
  public getVolume(): number {
    return Howler.volume();
  }

  // Mute
  public mute(): void {
    Howler.mute(true);
  }

  // Unmute
  public unmute(): void {
    Howler.mute(false);
  }

  // Toggle mute
  public toggleMute(): void {
    const isMuted = Howler._muted;
    Howler.mute(!isMuted);
  }

  // Unload current track
  public unload(): void {
    this.stopTimeUpdates();
    if (this.howl) {
      this.howl.unload();
      this.howl = null;
    }
    // Clean up offline URL
    if (this.offlineAudioURL) {
      revokeOfflineTrackURL(this.offlineAudioURL);
      this.offlineAudioURL = null;
    }
    this.currentTrack = null;
  }

  // Setup Web Audio API analyzer for visualizer
  private setupAudioAnalyser(): void {
    if (typeof window === 'undefined') return;

    try {
      // Get or create audio context
      if (!this.audioContext) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.audioContext = new AudioContextClass();
      }

      // Create analyser node
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.8;

      // Connect Howler to analyser
      // @ts-ignore - Howler.js internal API
      const masterGain = Howler.ctx._howlerNode;
      if (masterGain) {
        masterGain.connect(this.analyser);
        this.analyser.connect(this.audioContext.destination);
      }
    } catch (error) {
      console.error('Failed to setup audio analyser:', error);
    }
  }

  // Get analyser for visualizer
  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  // Get frequency data for visualizer
  public getFrequencyData(): Uint8Array {
    if (!this.analyser) return new Uint8Array(0);

    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  // Start time update interval
  private startTimeUpdates(): void {
    this.stopTimeUpdates();
    this.timeUpdateInterval = setInterval(() => {
      const currentTime = this.getCurrentTime();
      this.onTimeUpdate?.(currentTime);
    }, 100); // Update every 100ms
  }

  // Stop time update interval
  private stopTimeUpdates(): void {
    if (this.timeUpdateInterval) {
      clearInterval(this.timeUpdateInterval);
      this.timeUpdateInterval = null;
    }
  }

  // Cleanup
  public destroy(): void {
    this.unload();
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }
}

// Singleton instance
let audioEngineInstance: AudioEngine | null = null;

export function getAudioEngine(): AudioEngine {
  if (!audioEngineInstance) {
    audioEngineInstance = new AudioEngine();
  }
  return audioEngineInstance;
}
