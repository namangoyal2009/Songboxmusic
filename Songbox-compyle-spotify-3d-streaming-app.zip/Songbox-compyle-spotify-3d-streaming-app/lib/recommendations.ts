// AI Recommendation Engine
// Generates personalized recommendations based on listening history, liked songs, and time of day

import { Track } from '@/types/track';
import { detectMoodFromTrack, getTimeBasedMood, MoodCategory } from './mood-detection';
import { fetchTrendingTracks, searchTracks } from './audius';

interface UserProfile {
  likedSongs: Set<string>;
  listeningHistory: Array<{
    trackId: string;
    playedAt: string;
    duration: number;
  }>;
}

/**
 * Calculate genre frequency from tracks
 */
function calculateGenreFrequency(tracks: Track[]): Map<string, number> {
  const genreCount = new Map<string, number>();

  tracks.forEach((track) => {
    if (track.genre) {
      const normalizedGenre = track.genre.toLowerCase().trim();
      genreCount.set(normalizedGenre, (genreCount.get(normalizedGenre) || 0) + 1);
    }
  });

  return genreCount;
}

/**
 * Get top N genres from frequency map
 */
function getTopGenres(genreFrequency: Map<string, number>, n: number = 3): string[] {
  return Array.from(genreFrequency.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([genre]) => genre);
}

/**
 * Calculate mood frequency from tracks
 */
function calculateMoodFrequency(tracks: Track[]): Map<MoodCategory, number> {
  const moodCount = new Map<MoodCategory, number>();

  tracks.forEach((track) => {
    const mood = detectMoodFromTrack(track);
    moodCount.set(mood, (moodCount.get(mood) || 0) + 1);
  });

  return moodCount;
}

/**
 * Get recently played track IDs (last 30 days)
 */
function getRecentlyPlayedIds(
  listeningHistory: UserProfile['listeningHistory']
): Set<string> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  return new Set(
    listeningHistory
      .filter((entry) => new Date(entry.playedAt) > thirtyDaysAgo)
      .map((entry) => entry.trackId)
  );
}

/**
 * Score a track based on user preferences and context
 */
function scoreTrack(
  track: Track,
  userProfile: UserProfile,
  topGenres: string[],
  currentMood: MoodCategory,
  recentlyPlayed: Set<string>
): number {
  let score = 0;

  // Skip if recently played
  if (recentlyPlayed.has(track.id)) {
    return -1;
  }

  // Genre match (weight: 3)
  if (track.genre) {
    const normalizedGenre = track.genre.toLowerCase().trim();
    const genreIndex = topGenres.indexOf(normalizedGenre);
    if (genreIndex !== -1) {
      score += (3 - genreIndex) * 3; // Top genre gets 9 points, second gets 6, third gets 3
    }
  }

  // Mood match (weight: 2)
  const trackMood = detectMoodFromTrack(track);
  if (trackMood === currentMood) {
    score += 2;
  }

  // Trending score (weight: 1) - normalized play count
  // Assuming trending tracks have higher play counts
  const normalizedPlayCount = Math.min(track.playCount / 100000, 1); // Cap at 100k plays
  score += normalizedPlayCount;

  return score;
}

/**
 * Generate personalized recommendations
 */
export async function generateRecommendations(
  userProfile: UserProfile,
  allTracks: Track[], // All available tracks (liked + history)
  limit: number = 20
): Promise<Track[]> {
  // If user has no history, return trending tracks
  if (allTracks.length === 0) {
    try {
      const trending = await fetchTrendingTracks();
      return trending.slice(0, limit);
    } catch (error) {
      console.error('Error fetching trending tracks:', error);
      return [];
    }
  }

  // Calculate user preferences
  const genreFrequency = calculateGenreFrequency(allTracks);
  const topGenres = getTopGenres(genreFrequency, 3);

  const moodFrequency = calculateMoodFrequency(allTracks);
  const currentMood = getTimeBasedMood(); // Time-based mood suggestion

  const recentlyPlayed = getRecentlyPlayedIds(userProfile.listeningHistory);

  // Fetch trending tracks as candidates
  try {
    const trendingTracks = await fetchTrendingTracks(50); // Fetch more for better filtering

    // Score and sort tracks
    const scoredTracks = trendingTracks
      .map((track) => ({
        track,
        score: scoreTrack(track, userProfile, topGenres, currentMood, recentlyPlayed),
      }))
      .filter((item) => item.score > 0) // Remove recently played tracks
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map((item) => item.track);

    return scoredTracks;
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return [];
  }
}

/**
 * Generate mood-based playlist
 */
export async function generateMoodPlaylist(
  mood: MoodCategory,
  limit: number = 30
): Promise<Track[]> {
  try {
    // Fetch trending tracks
    const trendingTracks = await fetchTrendingTracks(100);

    // Filter by mood
    const moodTracks = trendingTracks
      .filter((track) => detectMoodFromTrack(track) === mood)
      .slice(0, limit);

    return moodTracks;
  } catch (error) {
    console.error('Error generating mood playlist:', error);
    return [];
  }
}

/**
 * Generate auto-playlists for different moods
 */
export async function generateAutoPlaylists(): Promise<
  Record<MoodCategory, Track[]>
> {
  const moods: MoodCategory[] = ['energetic', 'chill', 'happy', 'melancholic', 'focus'];

  const playlists: Record<MoodCategory, Track[]> = {
    energetic: [],
    chill: [],
    happy: [],
    melancholic: [],
    focus: [],
  };

  try {
    // Fetch a large pool of trending tracks
    const allTracks = await fetchTrendingTracks(100);

    // Categorize tracks by mood
    allTracks.forEach((track) => {
      const mood = detectMoodFromTrack(track);
      if (playlists[mood].length < 20) {
        playlists[mood].push(track);
      }
    });

    return playlists;
  } catch (error) {
    console.error('Error generating auto playlists:', error);
    return playlists;
  }
}

/**
 * Get similar tracks based on a seed track
 */
export async function getSimilarTracks(
  seedTrack: Track,
  limit: number = 10
): Promise<Track[]> {
  if (!seedTrack.genre) {
    return [];
  }

  try {
    // Search for tracks in the same genre
    const similarTracks = await searchTracks(seedTrack.genre);

    // Filter out the seed track and limit results
    return similarTracks
      .filter((track) => track.id !== seedTrack.id)
      .slice(0, limit);
  } catch (error) {
    console.error('Error fetching similar tracks:', error);
    return [];
  }
}

/**
 * Get personalized greeting based on user's listening patterns
 */
export function getPersonalizedGreeting(
  userProfile: UserProfile,
  allTracks: Track[]
): {
  greeting: string;
  tagline: string;
  mood: MoodCategory;
} {
  const hour = new Date().getHours();
  let timeGreeting = 'Good evening';

  if (hour >= 6 && hour < 12) {
    timeGreeting = 'Good morning';
  } else if (hour >= 12 && hour < 18) {
    timeGreeting = 'Good afternoon';
  }

  // Determine dominant mood from listening history
  let dominantMood: MoodCategory = getTimeBasedMood();

  if (allTracks.length > 0) {
    const moodFrequency = calculateMoodFrequency(allTracks);
    const topMood = Array.from(moodFrequency.entries()).sort((a, b) => b[1] - a[1])[0];
    if (topMood) {
      dominantMood = topMood[0];
    }
  }

  // Generate tagline based on mood
  const taglines = {
    energetic: "Here's your energy mix",
    chill: 'Your chill vibes await',
    happy: 'Feel-good tunes just for you',
    melancholic: 'Dive into deep tracks',
    focus: 'Get in the zone',
  };

  const newUserTaglines = {
    energetic: 'Discover high-energy tracks',
    chill: 'Find your perfect chill vibe',
    happy: 'Explore feel-good music',
    melancholic: 'Discover emotional soundscapes',
    focus: 'Find your focus soundtrack',
  };

  const tagline =
    allTracks.length > 0 ? taglines[dominantMood] : newUserTaglines[dominantMood];

  return {
    greeting: timeGreeting,
    tagline,
    mood: dominantMood,
  };
}

/**
 * Calculate recommendation confidence score (0-100)
 */
export function getRecommendationConfidence(userProfile: UserProfile): number {
  const listeningCount = userProfile.listeningHistory.length;
  const likedCount = userProfile.likedSongs.size;

  // More data = higher confidence
  const totalInteractions = listeningCount + likedCount * 2; // Likes count double

  // Confidence caps at 100 when user has 50+ interactions
  return Math.min(100, (totalInteractions / 50) * 100);
}
