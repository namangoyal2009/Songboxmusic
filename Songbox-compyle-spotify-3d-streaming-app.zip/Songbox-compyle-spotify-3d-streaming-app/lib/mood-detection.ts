// Mood Detection System
// Maps track genres to mood categories for visualizer selection and recommendations

import { Track } from '@/types/track';

export type MoodCategory = 'energetic' | 'chill' | 'happy' | 'melancholic' | 'focus';

// Genre to mood mapping
const genreMoodMap: Record<string, MoodCategory> = {
  // Energetic
  edm: 'energetic',
  electronic: 'energetic',
  dance: 'energetic',
  'hip-hop': 'energetic',
  'hip hop': 'energetic',
  rap: 'energetic',
  trap: 'energetic',
  dubstep: 'energetic',
  'drum and bass': 'energetic',
  'drum & bass': 'energetic',
  dnb: 'energetic',
  rock: 'energetic',
  metal: 'energetic',
  punk: 'energetic',
  hardcore: 'energetic',
  hardstyle: 'energetic',
  techno: 'energetic',
  trance: 'energetic',
  house: 'energetic',

  // Chill
  ambient: 'chill',
  'lo-fi': 'chill',
  lofi: 'chill',
  'lo fi': 'chill',
  chillhop: 'chill',
  chillout: 'chill',
  'chill out': 'chill',
  downtempo: 'chill',
  acoustic: 'chill',
  jazz: 'chill',
  classical: 'chill',
  'new age': 'chill',
  meditation: 'chill',
  relaxation: 'chill',
  sleep: 'chill',
  'easy listening': 'chill',

  // Happy
  pop: 'happy',
  funk: 'happy',
  disco: 'happy',
  reggae: 'happy',
  ska: 'happy',
  soul: 'happy',
  motown: 'happy',
  'dance pop': 'happy',
  'synth pop': 'happy',
  'indie pop': 'happy',
  'k-pop': 'happy',
  kpop: 'happy',
  'j-pop': 'happy',
  jpop: 'happy',

  // Melancholic
  indie: 'melancholic',
  alternative: 'melancholic',
  'indie rock': 'melancholic',
  'indie folk': 'melancholic',
  folk: 'melancholic',
  blues: 'melancholic',
  'singer-songwriter': 'melancholic',
  'singer songwriter': 'melancholic',
  emo: 'melancholic',
  grunge: 'melancholic',
  'sad songs': 'melancholic',
  ballad: 'melancholic',

  // Focus
  instrumental: 'focus',
  'study music': 'focus',
  'work music': 'focus',
  'focus music': 'focus',
  'concentration music': 'focus',
  'video game': 'focus',
  soundtrack: 'focus',
  'film score': 'focus',
  'game music': 'focus',
  'background music': 'focus',
};

/**
 * Detect mood from track genre
 */
export function detectMoodFromGenre(genre: string | null): MoodCategory {
  if (!genre) {
    return 'energetic'; // Default mood
  }

  const normalizedGenre = genre.toLowerCase().trim();

  // Direct match
  if (genreMoodMap[normalizedGenre]) {
    return genreMoodMap[normalizedGenre];
  }

  // Partial match (genre contains keyword)
  for (const [key, mood] of Object.entries(genreMoodMap)) {
    if (normalizedGenre.includes(key) || key.includes(normalizedGenre)) {
      return mood;
    }
  }

  // Default to energetic for unknown genres
  return 'energetic';
}

/**
 * Detect mood from track object
 */
export function detectMoodFromTrack(track: Track): MoodCategory {
  return detectMoodFromGenre(track.genre);
}

/**
 * Get mood color scheme for UI theming
 */
export function getMoodColors(mood: MoodCategory): {
  from: string;
  to: string;
  accent: string;
} {
  const colorSchemes = {
    energetic: {
      from: '#ef4444', // red
      to: '#f97316', // orange
      accent: '#dc2626',
    },
    chill: {
      from: '#3b82f6', // blue
      to: '#8b5cf6', // purple
      accent: '#6366f1',
    },
    happy: {
      from: '#fbbf24', // yellow
      to: '#10b981', // green
      accent: '#f59e0b',
    },
    melancholic: {
      from: '#1e3a8a', // deep blue
      to: '#374151', // gray
      accent: '#4b5563',
    },
    focus: {
      from: '#6366f1', // indigo
      to: '#4f46e5', // darker indigo
      accent: '#818cf8',
    },
  };

  return colorSchemes[mood];
}

/**
 * Get mood description for UI display
 */
export function getMoodDescription(mood: MoodCategory): string {
  const descriptions = {
    energetic: 'High energy, upbeat tracks to get you moving',
    chill: 'Relaxing, mellow vibes for winding down',
    happy: 'Feel-good music to lift your spirits',
    melancholic: 'Introspective, emotional soundscapes',
    focus: 'Concentration-enhancing background music',
  };

  return descriptions[mood];
}

/**
 * Get mood emoji for UI display
 */
export function getMoodEmoji(mood: MoodCategory): string {
  const emojis = {
    energetic: '⚡',
    chill: '😌',
    happy: '😊',
    melancholic: '🌙',
    focus: '🎯',
  };

  return emojis[mood];
}

/**
 * Get recommended visualizer mode for mood
 */
export function getVisualizerModeForMood(
  mood: MoodCategory
): 'particle' | 'wave' | 'shapes' {
  const moodVisualizerMap = {
    energetic: 'particle' as const,
    chill: 'wave' as const,
    happy: 'shapes' as const,
    melancholic: 'wave' as const,
    focus: 'shapes' as const,
  };

  return moodVisualizerMap[mood];
}

/**
 * Analyze multiple tracks to determine dominant mood
 */
export function analyzeDominantMood(tracks: Track[]): MoodCategory {
  if (tracks.length === 0) {
    return 'energetic';
  }

  const moodCounts: Record<MoodCategory, number> = {
    energetic: 0,
    chill: 0,
    happy: 0,
    melancholic: 0,
    focus: 0,
  };

  tracks.forEach((track) => {
    const mood = detectMoodFromTrack(track);
    moodCounts[mood]++;
  });

  // Find mood with highest count
  let dominantMood: MoodCategory = 'energetic';
  let maxCount = 0;

  for (const [mood, count] of Object.entries(moodCounts)) {
    if (count > maxCount) {
      maxCount = count;
      dominantMood = mood as MoodCategory;
    }
  }

  return dominantMood;
}

/**
 * Get time-of-day based mood suggestion
 */
export function getTimeBasedMood(): MoodCategory {
  const hour = new Date().getHours();

  if (hour >= 6 && hour < 10) {
    // Morning (6am - 10am)
    return 'energetic'; // Wake up energy
  } else if (hour >= 10 && hour < 14) {
    // Late morning / Midday (10am - 2pm)
    return 'focus'; // Work/focus time
  } else if (hour >= 14 && hour < 18) {
    // Afternoon (2pm - 6pm)
    return 'happy'; // Positive afternoon vibes
  } else if (hour >= 18 && hour < 22) {
    // Evening (6pm - 10pm)
    return 'chill'; // Wind down
  } else {
    // Late night / Early morning (10pm - 6am)
    return 'melancholic'; // Late night introspection
  }
}

/**
 * Get mood-based greeting message
 */
export function getMoodBasedGreeting(mood: MoodCategory): string {
  const greetings = {
    energetic: "Let's get moving with some high energy tunes!",
    chill: 'Time to relax with some mellow vibes.',
    happy: 'Spread the joy with feel-good music!',
    melancholic: 'Dive into some introspective melodies.',
    focus: 'Get in the zone with focus-enhancing sounds.',
  };

  return greetings[mood];
}
