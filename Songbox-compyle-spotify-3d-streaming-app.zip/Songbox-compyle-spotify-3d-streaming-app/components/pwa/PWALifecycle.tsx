'use client';

import { useEffect } from 'react';
import { registerServiceWorker } from '@/lib/pwa';
import InstallBanner from './InstallBanner';
import MobileNav from '@/components/layout/MobileNav';
import MiniPlayer from '@/components/player/MiniPlayer';

const PWALifecycle: React.FC = () => {
  useEffect(() => {
    // Register service worker
    registerServiceWorker();

    // Prevent zoom on iOS
    const preventZoom = (e: TouchEvent) => {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    };

    document.addEventListener('touchstart', preventZoom, { passive: false });

    return () => {
      document.removeEventListener('touchstart', preventZoom);
    };
  }, []);

  return (
    <>
      {/* PWA Install Banner */}
      <InstallBanner />

      {/* Mobile Bottom Navigation */}
      <MobileNav />

      {/* Mobile Mini Player */}
      <MiniPlayer />
    </>
  );
};

export default PWALifecycle;
