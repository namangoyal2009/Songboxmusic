'use client';

import { Suspense, useState, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import AudioAnalyzer, { AudioData } from './AudioAnalyzer';
import ParticleField from './ParticleField';
import GeometricWave from './GeometricWave';
import AbstractShapes from './AbstractShapes';
import { useAudioStore } from '@/store/audioStore';
import { moodToVisualizer } from '@/types/track';
import * as THREE from 'three';

const VisualizerCanvas: React.FC = () => {
  const { currentTrack } = useAudioStore();
  const [audioData, setAudioData] = useState<AudioData>({
    frequencyData: new Uint8Array(0),
    bass: 0,
    mid: 0,
    treble: 0,
    average: 0,
    isPlaying: false,
  });

  // Determine visualizer mode based on current track mood
  const visualizerMode = useMemo(() => {
    if (!currentTrack) return 'particle';
    return moodToVisualizer(currentTrack.mood);
  }, [currentTrack]);

  // Vibe Mode: Dynamic colors based on mood
  const vibeColor = useMemo(() => {
    if (!currentTrack) return '#6366f1';

    switch (currentTrack.mood) {
      case 'energetic':
        return '#ef4444'; // Red
      case 'chill':
        return '#3b82f6'; // Blue
      case 'happy':
        return '#fbbf24'; // Yellow
      case 'melancholic':
        return '#6366f1'; // Indigo
      case 'focus':
        return '#8b5cf6'; // Purple
      default:
        return '#6366f1';
    }
  }, [currentTrack]);

  // Background gradient based on mood
  const backgroundColors = useMemo(() => {
    if (!currentTrack) return ['#0a0a0a', '#1a1a2e'];

    switch (currentTrack.mood) {
      case 'energetic':
        return ['#1a0a0a', '#2a0a0a']; // Dark red
      case 'chill':
        return ['#0a0a1a', '#0a1a2a']; // Dark blue
      case 'happy':
        return ['#1a1a0a', '#2a2a0a']; // Dark yellow
      case 'melancholic':
        return ['#0a0a1a', '#1a0a2a']; // Dark indigo
      case 'focus':
        return ['#0a0a1a', '#1a0a2a']; // Dark purple
      default:
        return ['#0a0a0a', '#1a1a2e'];
    }
  }, [currentTrack]);

  return (
    <div className="fixed inset-0 -z-10">
      {/* Dynamic Background Gradient */}
      <div
        className="absolute inset-0 transition-all duration-[3000ms]"
        style={{
          background: `linear-gradient(135deg, ${backgroundColors[0]} 0%, ${backgroundColors[1]} 100%)`,
        }}
      />

      {/* Three.js Canvas */}
      <Canvas
        camera={{ position: [0, 0, 15], fov: 75 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: 'transparent' }}
      >
        <Suspense fallback={null}>
          {/* Lighting */}
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} color={vibeColor} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color={vibeColor} />

          {/* Visualizers - switch based on mode */}
          {visualizerMode === 'particle' && (
            <ParticleField audioData={audioData} color={vibeColor} />
          )}
          {visualizerMode === 'wave' && (
            <GeometricWave audioData={audioData} color={vibeColor} />
          )}
          {visualizerMode === 'shapes' && (
            <AbstractShapes audioData={audioData} color={vibeColor} />
          )}

          {/* Camera controls - subtle */}
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            autoRotate={false}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 1.5}
          />
        </Suspense>
      </Canvas>

      {/* Audio Analyzer - extracts frequency data */}
      <AudioAnalyzer onData={setAudioData} />
    </div>
  );
};

export default VisualizerCanvas;
