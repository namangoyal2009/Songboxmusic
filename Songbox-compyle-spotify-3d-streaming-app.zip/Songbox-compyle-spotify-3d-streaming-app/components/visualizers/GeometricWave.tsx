'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { AudioData } from './AudioAnalyzer';

interface GeometricWaveProps {
  audioData: AudioData;
  color?: string;
}

const GeometricWave: React.FC<GeometricWaveProps> = ({ audioData, color = '#3b82f6' }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
  const gridSize = isMobile ? 30 : 50;

  const geometry = useMemo(() => {
    const geo = new THREE.PlaneGeometry(20, 20, gridSize, gridSize);
    geo.rotateX(-Math.PI / 2);
    return geo;
  }, [gridSize]);

  useFrame((state) => {
    if (!meshRef.current) return;

    const { bass, mid, treble, average, isPlaying } = audioData;
    const time = state.clock.getElapsedTime();

    const positions = meshRef.current.geometry.attributes.position.array as Float32Array;

    for (let i = 0; i < positions.length / 3; i++) {
      const x = positions[i * 3];
      const z = positions[i * 3 + 2];

      const distance = Math.sqrt(x * x + z * z);
      const wave1 = Math.sin(distance * 0.5 - time * 2) * 0.5;
      const wave2 = Math.cos(distance * 0.3 + time) * 0.3;

      if (isPlaying) {
        const audioEffect = (bass * 2 + mid + treble) / 4;
        positions[i * 3 + 1] = (wave1 + wave2) * (1 + audioEffect * 2);
      } else {
        positions[i * 3 + 1] = (wave1 + wave2) * 0.5;
      }
    }

    meshRef.current.geometry.attributes.position.needsUpdate = true;
    meshRef.current.geometry.computeVertexNormals();

    // Gentle rotation
    if (isPlaying) {
      meshRef.current.rotation.z += 0.001 + average * 0.002;
    } else {
      meshRef.current.rotation.z += 0.0005;
    }
  });

  return (
    <mesh ref={meshRef} geometry={geometry}>
      <meshStandardMaterial
        color={color}
        wireframe
        transparent
        opacity={0.6}
      />
    </mesh>
  );
};

export default GeometricWave;
