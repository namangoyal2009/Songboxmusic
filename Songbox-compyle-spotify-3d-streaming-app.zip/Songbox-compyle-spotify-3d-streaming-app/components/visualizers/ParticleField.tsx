'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { AudioData } from './AudioAnalyzer';

interface ParticleFieldProps {
  audioData: AudioData;
  color?: string;
}

const ParticleField: React.FC<ParticleFieldProps> = ({ audioData, color = '#6366f1' }) => {
  const particlesRef = useRef<THREE.Points>(null);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
  const particleCount = isMobile ? 2000 : 5000;

  const [positions, colors] = useMemo(() => {
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Random position in a sphere
      const radius = Math.random() * 15 + 5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);

      // Base color
      const c = new THREE.Color(color);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }

    return [positions, colors];
  }, [particleCount, color]);

  useFrame((state) => {
    if (!particlesRef.current) return;

    const { bass, mid, treble, average, isPlaying } = audioData;
    const time = state.clock.getElapsedTime();

    // Rotation
    if (isPlaying) {
      particlesRef.current.rotation.y += 0.001 + bass * 0.01;
      particlesRef.current.rotation.x += 0.0005 + mid * 0.005;
    } else {
      particlesRef.current.rotation.y += 0.0005;
    }

    // Update particle positions and colors
    const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
    const colors = particlesRef.current.geometry.attributes.color.array as Float32Array;

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;

      if (isPlaying) {
        // React to audio
        const intensity = (bass + mid + treble) / 3;
        const wave = Math.sin(time + i * 0.01) * intensity * 2;

        positions[i3 + 1] += wave * 0.02;

        // Color intensity based on audio
        const baseColor = new THREE.Color(color);
        const intensity2 = 0.5 + average * 0.5;
        colors[i3] = baseColor.r * intensity2;
        colors[i3 + 1] = baseColor.g * intensity2;
        colors[i3 + 2] = baseColor.b * intensity2;
      }
    }

    particlesRef.current.geometry.attributes.position.needsUpdate = true;
    particlesRef.current.geometry.attributes.color.needsUpdate = true;
  });

  return (
    <points ref={particlesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={particleCount}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={particleCount}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.1}
        vertexColors
        transparent
        opacity={0.8}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default ParticleField;
