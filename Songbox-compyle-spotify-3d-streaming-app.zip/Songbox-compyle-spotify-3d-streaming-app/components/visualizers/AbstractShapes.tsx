'use client';

import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { AudioData } from './AudioAnalyzer';

interface AbstractShapesProps {
  audioData: AudioData;
  color?: string;
}

const AbstractShapes: React.FC<AbstractShapesProps> = ({ audioData, color = '#8b5cf6' }) => {
  const group = useRef<THREE.Group>(null);
  const sphere1 = useRef<THREE.Mesh>(null);
  const sphere2 = useRef<THREE.Mesh>(null);
  const sphere3 = useRef<THREE.Mesh>(null);
  const torus = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!group.current) return;

    const { bass, mid, treble, average, isPlaying } = audioData;
    const time = state.clock.getElapsedTime();

    // Rotate group
    if (isPlaying) {
      group.current.rotation.y += 0.005 + average * 0.01;
      group.current.rotation.x += 0.002 + bass * 0.005;
    } else {
      group.current.rotation.y += 0.002;
      group.current.rotation.x += 0.001;
    }

    // Animate sphere 1 (center)
    if (sphere1.current && isPlaying) {
      const scale = 1 + bass * 0.5;
      sphere1.current.scale.setScalar(scale);
      sphere1.current.rotation.y += 0.01;
    }

    // Animate sphere 2 (orbiting)
    if (sphere2.current) {
      sphere2.current.position.x = Math.cos(time) * 4;
      sphere2.current.position.z = Math.sin(time) * 4;
      if (isPlaying) {
        const scale = 0.8 + mid * 0.4;
        sphere2.current.scale.setScalar(scale);
      }
    }

    // Animate sphere 3 (orbiting opposite)
    if (sphere3.current) {
      sphere3.current.position.x = Math.cos(time + Math.PI) * 4;
      sphere3.current.position.z = Math.sin(time + Math.PI) * 4;
      if (isPlaying) {
        const scale = 0.8 + treble * 0.4;
        sphere3.current.scale.setScalar(scale);
      }
    }

    // Animate torus
    if (torus.current && isPlaying) {
      torus.current.rotation.x += 0.01 + mid * 0.02;
      torus.current.rotation.y += 0.005 + treble * 0.01;
      const scale = 1 + average * 0.3;
      torus.current.scale.setScalar(scale);
    }
  });

  return (
    <group ref={group}>
      {/* Center sphere */}
      <mesh ref={sphere1}>
        <icosahedronGeometry args={[1.5, 1]} />
        <meshStandardMaterial color={color} wireframe transparent opacity={0.7} />
      </mesh>

      {/* Orbiting sphere 1 */}
      <mesh ref={sphere2} position={[4, 0, 0]}>
        <octahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial color={color} wireframe transparent opacity={0.6} />
      </mesh>

      {/* Orbiting sphere 2 */}
      <mesh ref={sphere3} position={[-4, 0, 0]}>
        <tetrahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial color={color} wireframe transparent opacity={0.6} />
      </mesh>

      {/* Torus */}
      <mesh ref={torus} position={[0, 0, 0]}>
        <torusGeometry args={[3, 0.3, 16, 100]} />
        <meshStandardMaterial color={color} wireframe transparent opacity={0.5} />
      </mesh>
    </group>
  );
};

export default AbstractShapes;
