'use client';

import { useEffect, useRef } from 'react';
import { useAudioStore } from '@/store/audioStore';
import { getAudioEngine } from '@/lib/audio-engine';

export interface AudioData {
  frequencyData: Uint8Array;
  bass: number;
  mid: number;
  treble: number;
  average: number;
  isPlaying: boolean;
}

interface AudioAnalyzerProps {
  onData: (data: AudioData) => void;
}

const AudioAnalyzer: React.FC<AudioAnalyzerProps> = ({ onData }) => {
  const { isPlaying } = useAudioStore();
  const rafRef = useRef<number>();
  const audioEngine = getAudioEngine();

  useEffect(() => {
    const analyze = () => {
      const frequencyData = audioEngine.getFrequencyData();

      if (frequencyData.length > 0 && isPlaying) {
        const dataLength = frequencyData.length;

        // Calculate frequency bands
        const bassEnd = Math.floor(dataLength * 0.1);
        const midEnd = Math.floor(dataLength * 0.4);

        let bassSum = 0;
        let midSum = 0;
        let trebleSum = 0;
        let totalSum = 0;

        for (let i = 0; i < dataLength; i++) {
          const value = frequencyData[i];
          totalSum += value;

          if (i < bassEnd) {
            bassSum += value;
          } else if (i < midEnd) {
            midSum += value;
          } else {
            trebleSum += value;
          }
        }

        const bass = bassSum / bassEnd / 255;
        const mid = midSum / (midEnd - bassEnd) / 255;
        const treble = trebleSum / (dataLength - midEnd) / 255;
        const average = totalSum / dataLength / 255;

        onData({
          frequencyData,
          bass,
          mid,
          treble,
          average,
          isPlaying,
        });
      } else {
        // Send silent data when not playing
        onData({
          frequencyData: new Uint8Array(0),
          bass: 0,
          mid: 0,
          treble: 0,
          average: 0,
          isPlaying: false,
        });
      }

      rafRef.current = requestAnimationFrame(analyze);
    };

    rafRef.current = requestAnimationFrame(analyze);

    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [isPlaying, onData]);

  return null; // This component only handles audio analysis
};

export default AudioAnalyzer;
