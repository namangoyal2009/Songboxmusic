'use client';

import { useState } from 'react';
import { Track } from '@/types/track';
import { AudiusUser, AudiusPlaylist } from '@/types/audius';
import TrackList from '@/components/track/TrackList';
import { cn } from '@/lib/utils';

interface SearchResultsProps {
  tracks: Track[];
  artists: AudiusUser[];
  playlists: AudiusPlaylist[];
  loading: boolean;
  onLoadMoreTracks?: () => void;
  hasMoreTracks?: boolean;
  isLoadingMoreTracks?: boolean;
}

type Tab = 'all' | 'songs' | 'artists' | 'playlists';

const SearchResults: React.FC<SearchResultsProps> = ({
  tracks,
  artists,
  playlists,
  loading,
  onLoadMoreTracks,
  hasMoreTracks = false,
  isLoadingMoreTracks = false,
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('all');

  const tabs: { id: Tab; label: string; count: number }[] = [
    { id: 'all', label: 'All', count: tracks.length + artists.length + playlists.length },
    { id: 'songs', label: 'Songs', count: tracks.length },
    { id: 'artists', label: 'Artists', count: artists.length },
    { id: 'playlists', label: 'Playlists', count: playlists.length },
  ];

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="flex gap-4 border-b border-white/10">
          {tabs.map((tab) => (
            <div key={tab.id} className="px-4 py-3 bg-white/5 rounded-t-lg w-24 h-10 animate-pulse" />
          ))}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="bg-white/5 rounded-lg h-64 animate-pulse shimmer" />
          ))}
        </div>
      </div>
    );
  }

  const hasResults = tracks.length > 0 || artists.length > 0 || playlists.length > 0;

  if (!hasResults) {
    return (
      <div className="text-center py-12">
        <svg className="w-16 h-16 mx-auto mb-4 text-foreground-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <h3 className="text-xl font-semibold text-foreground mb-2">No results found</h3>
        <p className="text-foreground-secondary">Try searching for something else</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-white/10 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'px-4 py-3 text-sm font-medium whitespace-nowrap transition-all',
              activeTab === tab.id
                ? 'text-primary border-b-2 border-primary'
                : 'text-foreground-secondary hover:text-foreground'
            )}
          >
            {tab.label}
            <span className="ml-2 text-xs opacity-75">({tab.count})</span>
          </button>
        ))}
      </div>

      {/* Content */}
      {(activeTab === 'all' || activeTab === 'songs') && tracks.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Songs</h2>
          <TrackList
            tracks={activeTab === 'all' ? tracks.slice(0, 10) : tracks}
            columns={5}
            onLoadMore={activeTab === 'songs' ? onLoadMoreTracks : undefined}
            hasMore={activeTab === 'songs' ? hasMoreTracks : false}
            isLoading={activeTab === 'songs' ? isLoadingMoreTracks : false}
          />
        </div>
      )}

      {(activeTab === 'all' || activeTab === 'artists') && artists.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Artists</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {(activeTab === 'all' ? artists.slice(0, 6) : artists).map((artist) => (
              <div
                key={artist.id}
                className="group cursor-pointer"
              >
                <div className="aspect-square rounded-full overflow-hidden mb-3 bg-gradient-to-br from-primary/30 to-secondary/30 group-hover:scale-105 transition-transform">
                  {artist.profile_picture?.['480x480'] && (
                    <img
                      src={artist.profile_picture['480x480']}
                      alt={artist.name}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <h3 className="font-medium text-foreground text-center truncate">{artist.name}</h3>
                <p className="text-sm text-foreground-secondary text-center">Artist</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {(activeTab === 'all' || activeTab === 'playlists') && playlists.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-foreground mb-4">Playlists</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {(activeTab === 'all' ? playlists.slice(0, 5) : playlists).map((playlist) => (
              <div
                key={playlist.id}
                className="group cursor-pointer bg-white/5 rounded-lg p-4 hover:bg-white/10 transition-all"
              >
                <div className="aspect-square rounded-md overflow-hidden mb-3 bg-gradient-to-br from-primary/30 to-secondary/30">
                  {playlist.artwork?.['480x480'] && (
                    <img
                      src={playlist.artwork['480x480']}
                      alt={playlist.playlist_name}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <h3 className="font-medium text-foreground line-clamp-2 mb-1">{playlist.playlist_name}</h3>
                <p className="text-sm text-foreground-secondary">{playlist.track_count} tracks</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchResults;
