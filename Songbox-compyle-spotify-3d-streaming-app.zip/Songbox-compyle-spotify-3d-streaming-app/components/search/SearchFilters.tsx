'use client';

import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

export interface FilterOptions {
  sortBy: 'relevance' | 'popularity' | 'recent';
  duration: 'any' | 'short' | 'medium' | 'long';
}

interface SearchFiltersProps {
  onFilterChange: (filters: FilterOptions) => void;
  className?: string;
}

const STORAGE_KEY = 'songbox_search_filters';

const SearchFilters: React.FC<SearchFiltersProps> = ({ onFilterChange, className }) => {
  const [sortBy, setSortBy] = useState<FilterOptions['sortBy']>('relevance');
  const [duration, setDuration] = useState<FilterOptions['duration']>('any');

  // Load filters from localStorage on mount
  useEffect(() => {
    const savedFilters = localStorage.getItem(STORAGE_KEY);
    if (savedFilters) {
      try {
        const parsed = JSON.parse(savedFilters) as FilterOptions;
        setSortBy(parsed.sortBy);
        setDuration(parsed.duration);
        onFilterChange(parsed);
      } catch (error) {
        console.error('Failed to parse saved filters:', error);
      }
    }
  }, []);

  // Save filters and notify parent
  const handleFilterChange = (newSortBy: FilterOptions['sortBy'], newDuration: FilterOptions['duration']) => {
    const filters: FilterOptions = { sortBy: newSortBy, duration: newDuration };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filters));
    onFilterChange(filters);
  };

  const handleSortChange = (value: FilterOptions['sortBy']) => {
    setSortBy(value);
    handleFilterChange(value, duration);
  };

  const handleDurationChange = (value: FilterOptions['duration']) => {
    setDuration(value);
    handleFilterChange(sortBy, value);
  };

  const resetFilters = () => {
    setSortBy('relevance');
    setDuration('any');
    handleFilterChange('relevance', 'any');
  };

  const hasActiveFilters = sortBy !== 'relevance' || duration !== 'any';

  return (
    <div className={cn('flex flex-wrap items-center gap-3', className)}>
      {/* Sort By Filter */}
      <div className="flex items-center gap-2">
        <label className="text-sm font-medium text-foreground-secondary whitespace-nowrap">
          Sort by:
        </label>
        <select
          value={sortBy}
          onChange={(e) => handleSortChange(e.target.value as FilterOptions['sortBy'])}
          className="px-3 py-2 bg-background-surface border border-white/10 rounded-lg text-sm text-foreground focus:outline-none focus:border-primary transition-colors cursor-pointer"
        >
          <option value="relevance">Relevance</option>
          <option value="popularity">Popularity</option>
          <option value="recent">Recent</option>
        </select>
      </div>

      {/* Duration Filter */}
      <div className="flex items-center gap-2">
        <label className="text-sm font-medium text-foreground-secondary whitespace-nowrap">
          Duration:
        </label>
        <select
          value={duration}
          onChange={(e) => handleDurationChange(e.target.value as FilterOptions['duration'])}
          className="px-3 py-2 bg-background-surface border border-white/10 rounded-lg text-sm text-foreground focus:outline-none focus:border-primary transition-colors cursor-pointer"
        >
          <option value="any">Any</option>
          <option value="short">Short (&lt;3 min)</option>
          <option value="medium">Medium (3-5 min)</option>
          <option value="long">Long (&gt;5 min)</option>
        </select>
      </div>

      {/* Reset Button */}
      {hasActiveFilters && (
        <button
          onClick={resetFilters}
          className="px-3 py-2 text-sm text-foreground-secondary hover:text-foreground transition-colors"
        >
          Reset filters
        </button>
      )}
    </div>
  );
};

export default SearchFilters;
