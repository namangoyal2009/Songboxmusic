'use client';

import { motion } from 'framer-motion';

interface LoadingProps {
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
  message?: string;
}

const Loading: React.FC<LoadingProps> = ({ size = 'md', fullScreen = false, message }) => {
  const sizes = {
    sm: 'w-6 h-6',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
  };

  const spinner = (
    <motion.div
      className={`${sizes[size]} border-4 border-white/20 border-t-primary rounded-full`}
      animate={{ rotate: 360 }}
      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
    />
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-4">
          {spinner}
          {message && <p className="text-foreground-secondary text-sm">{message}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center p-8">
      <div className="flex flex-col items-center gap-4">
        {spinner}
        {message && <p className="text-foreground-secondary text-sm">{message}</p>}
      </div>
    </div>
  );
};

export default Loading;

// Simple inline spinner for buttons
export const Spinner: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <motion.div
    className={`${className} border-2 border-white/30 border-t-white rounded-full`}
    animate={{ rotate: 360 }}
    transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
  />
);
