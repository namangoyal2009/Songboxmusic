'use client';

import { Track } from '@/types/track';
import TrackCard from './TrackCard';
import { useInfiniteScroll } from '@/lib/hooks/useInfiniteScroll';

interface TrackListProps {
  tracks: Track[];
  title?: string;
  description?: string;
  columns?: 2 | 3 | 4 | 5;
  onLoadMore?: () => void;
  hasMore?: boolean;
  isLoading?: boolean;
}

const TrackList: React.FC<TrackListProps> = ({
  tracks,
  title,
  description,
  columns = 4,
  onLoadMore,
  hasMore = false,
  isLoading = false,
}) => {
  const gridCols = {
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4',
    5: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5',
  };

  const { loadMoreRef } = useInfiniteScroll({
    onLoadMore: onLoadMore || (() => {}),
    hasMore,
    isLoading,
  });

  if (tracks.length === 0 && !isLoading) {
    return (
      <div className="text-center py-12">
        <p className="text-foreground-secondary">No tracks found</p>
      </div>
    );
  }

  return (
    <div>
      {(title || description) && (
        <div className="mb-6">
          {title && <h2 className="text-2xl font-bold text-foreground mb-2">{title}</h2>}
          {description && <p className="text-foreground-secondary">{description}</p>}
        </div>
      )}

      <div className={`grid gap-4 ${gridCols[columns]}`}>
        {tracks.map((track) => (
          <TrackCard key={track.id} track={track} playlist={tracks} />
        ))}
      </div>

      {/* Loading skeleton for infinite scroll */}
      {isLoading && (
        <div className={`grid gap-4 ${gridCols[columns]} mt-4`}>
          {[...Array(8)].map((_, i) => (
            <div key={i} className="bg-white/5 rounded-lg h-64 animate-pulse" />
          ))}
        </div>
      )}

      {/* Intersection observer target */}
      {hasMore && !isLoading && onLoadMore && (
        <div ref={loadMoreRef} className="h-20 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {/* No more results message */}
      {!hasMore && tracks.length > 0 && onLoadMore && (
        <div className="text-center py-8">
          <p className="text-foreground-secondary text-sm">No more results</p>
        </div>
      )}
    </div>
  );
};

export default TrackList;
