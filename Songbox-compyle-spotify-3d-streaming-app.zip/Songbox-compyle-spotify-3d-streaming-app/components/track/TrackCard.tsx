'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Track } from '@/types/track';
import Card from '@/components/ui/Card';
import { useAudioStore } from '@/store/audioStore';
import { useUserStore } from '@/store/userStore';
import { formatDuration, formatNumber } from '@/lib/utils';
import { downloadTrackOffline, isTrackDownloaded, deleteOfflineTrack } from '@/lib/offline-storage';

interface TrackCardProps {
  track: Track;
  playlist?: Track[];
}

const TrackCard: React.FC<TrackCardProps> = ({ track, playlist }) => {
  const { playTrack, addToQueue, currentTrack, isPlaying } = useAudioStore();
  const { toggleLike, isLiked } = useUserStore();

  const [isDownloaded, setIsDownloaded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const isCurrentTrack = currentTrack?.id === track.id;

  // Check if track is downloaded on mount
  useEffect(() => {
    const checkDownloadStatus = async () => {
      const downloaded = await isTrackDownloaded(track.id);
      setIsDownloaded(downloaded);
    };
    checkDownloadStatus();
  }, [track.id]);

  const handlePlay = () => {
    if (playlist) {
      playTrack(track, playlist);
    } else {
      playTrack(track);
    }
  };

  const handleAddToQueue = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToQueue(track);
  };

  const handleToggleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleLike(track.id);
  };

  const handleDownloadToggle = async (e: React.MouseEvent) => {
    e.stopPropagation();

    if (isDownloaded) {
      // Delete downloaded track
      try {
        await deleteOfflineTrack(track.id);
        setIsDownloaded(false);
      } catch (error) {
        console.error('Failed to delete offline track:', error);
      }
    } else {
      // Download track
      try {
        setIsDownloading(true);
        await downloadTrackOffline(track);
        setIsDownloaded(true);
      } catch (error) {
        console.error('Failed to download track:', error);
      } finally {
        setIsDownloading(false);
      }
    }
  };

  const liked = isLiked(track.id);

  return (
    <Card
      hover
      padding="md"
      className="group cursor-pointer relative"
      onClick={handlePlay}
    >
      {/* Album Artwork */}
      <div className="relative aspect-square mb-3 overflow-hidden rounded-md">
        {track.artwork ? (
          <Image
            src={track.artwork}
            alt={track.title}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/30 to-secondary/30" />
        )}

        {/* Play Button Overlay */}
        <div
          className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
            isCurrentTrack && isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePlay();
            }}
            className="w-12 h-12 rounded-full bg-primary flex items-center justify-center shadow-glow transform group-hover:scale-110 transition-transform"
          >
            {isCurrentTrack && isPlaying ? (
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                  clipRule="evenodd"
                />
              </svg>
            ) : (
              <svg className="w-6 h-6 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
                <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
              </svg>
            )}
          </button>
        </div>

        {/* Playing Indicator */}
        {isCurrentTrack && isPlaying && (
          <div className="absolute top-2 right-2 bg-primary px-2 py-1 rounded-full text-xs text-white font-medium">
            Playing
          </div>
        )}
      </div>

      {/* Track Info */}
      <h3 className="font-medium text-foreground line-clamp-1 mb-1">{track.title}</h3>
      <p className="text-sm text-foreground-secondary line-clamp-1 mb-2">{track.artist}</p>

      {/* Metadata */}
      <div className="flex items-center justify-between text-xs text-foreground-muted">
        <span className="flex items-center gap-1">
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
            <path
              fillRule="evenodd"
              d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z"
              clipRule="evenodd"
            />
          </svg>
          {formatNumber(track.playCount)}
        </span>
        <span>{formatDuration(track.duration)}</span>
      </div>

      {/* Quick Actions */}
      <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={handleToggleLike}
          className={`p-2 rounded-md transition-colors ${
            liked ? 'bg-primary/20 text-primary' : 'bg-white/5 hover:bg-white/10 text-foreground-secondary'
          }`}
          title={liked ? 'Unlike' : 'Like'}
        >
          <svg className="w-4 h-4" fill={liked ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
            />
          </svg>
        </button>
        <button
          onClick={handleDownloadToggle}
          disabled={isDownloading}
          className={`p-2 rounded-md transition-colors ${
            isDownloaded
              ? 'bg-secondary/20 text-secondary'
              : isDownloading
              ? 'bg-white/5 text-foreground-muted cursor-not-allowed'
              : 'bg-white/5 hover:bg-white/10 text-foreground-secondary'
          }`}
          title={isDownloaded ? 'Downloaded' : isDownloading ? 'Downloading...' : 'Download for offline'}
        >
          {isDownloading ? (
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
          ) : isDownloaded ? (
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                clipRule="evenodd"
              />
            </svg>
          ) : (
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
              />
            </svg>
          )}
        </button>
        <button
          onClick={handleAddToQueue}
          className="flex-1 px-3 py-1.5 text-xs bg-white/5 hover:bg-white/10 rounded-md transition-colors"
        >
          Add to Queue
        </button>
      </div>
    </Card>
  );
};

export default TrackCard;
