'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Track } from '@/types/track';
import { fetchLyrics } from '@/lib/lyrics-api';

interface LyricsModalProps {
  isOpen: boolean;
  onClose: () => void;
  track: Track | null;
}

const LyricsModal: React.FC<LyricsModalProps> = ({ isOpen, onClose, track }) => {
  const [lyrics, setLyrics] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [source, setSource] = useState<string>('');

  useEffect(() => {
    if (isOpen && track) {
      loadLyrics();
    } else {
      // Reset state when closed
      setLyrics(null);
      setError(null);
      setSource('');
    }
  }, [isOpen, track]);

  const loadLyrics = async () => {
    if (!track) return;

    setLoading(true);
    setError(null);

    try {
      const result = await fetchLyrics(track.id, track.artist, track.title);

      if (result.lyrics) {
        setLyrics(result.lyrics);
        setSource(result.source);
      } else {
        setError('Lyrics not found for this track');
      }
    } catch (err) {
      console.error('Error loading lyrics:', err);
      setError('Failed to load lyrics. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!track) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
          />

          {/* Lyrics Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
          >
            <div
              className="bg-background-surface/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col pointer-events-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-start justify-between p-6 border-b border-white/10">
                <div className="flex-1 pr-4">
                  <h2 className="text-2xl font-bold text-foreground mb-1">{track.title}</h2>
                  <p className="text-foreground-secondary">{track.artist}</p>
                  {source && (
                    <p className="text-xs text-foreground-muted mt-2">Source: {source}</p>
                  )}
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/5 rounded-lg transition-colors flex-shrink-0"
                >
                  <svg
                    className="w-6 h-6 text-foreground"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {loading && (
                  <div className="flex flex-col items-center justify-center py-12">
                    <svg
                      className="w-12 h-12 text-primary animate-spin mb-4"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      />
                    </svg>
                    <p className="text-foreground-secondary">Loading lyrics...</p>
                  </div>
                )}

                {error && !loading && (
                  <div className="flex flex-col items-center justify-center py-12">
                    <svg
                      className="w-16 h-16 text-foreground-muted mb-4"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      Lyrics Not Found
                    </h3>
                    <p className="text-foreground-secondary text-center max-w-sm">
                      {error}
                    </p>
                    <button
                      onClick={loadLyrics}
                      className="mt-6 px-4 py-2 bg-primary hover:bg-primary-dark rounded-lg text-white text-sm font-medium transition-colors"
                    >
                      Try Again
                    </button>
                  </div>
                )}

                {lyrics && !loading && !error && (
                  <div className="whitespace-pre-wrap text-foreground leading-relaxed">
                    {lyrics}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-6 border-t border-white/10">
                <p className="text-xs text-foreground-muted text-center">
                  Lyrics are fetched from public APIs and may not be 100% accurate
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default LyricsModal;
