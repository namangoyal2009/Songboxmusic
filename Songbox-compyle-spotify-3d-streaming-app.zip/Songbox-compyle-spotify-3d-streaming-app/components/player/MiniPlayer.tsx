'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useAudioStore } from '@/store/audioStore';
import FullScreenPlayer from './FullScreenPlayer';

const MiniPlayer: React.FC = () => {
  const { currentTrack, isPlaying, togglePlay } = useAudioStore();
  const [showFullScreen, setShowFullScreen] = useState(false);

  if (!currentTrack) {
    return null;
  }

  return (
    <>
      {/* Mini Player Bar */}
      <motion.div
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-background-surface/95 backdrop-blur-xl border-t border-white/10"
        onClick={() => setShowFullScreen(true)}
      >
        <div className="flex items-center gap-3 px-4 py-3">
          {/* Album Art */}
          {currentTrack.artwork ? (
            <Image
              src={currentTrack.artwork}
              alt={currentTrack.title}
              width={48}
              height={48}
              className="w-12 h-12 rounded-md object-cover flex-shrink-0"
            />
          ) : (
            <div className="w-12 h-12 rounded-md bg-gradient-to-br from-primary/30 to-secondary/30 flex-shrink-0" />
          )}

          {/* Track Info */}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {currentTrack.title}
            </p>
            <p className="text-xs text-foreground-secondary truncate">
              {currentTrack.artist}
            </p>
          </div>

          {/* Play/Pause Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              togglePlay();
            }}
            className="w-10 h-10 rounded-full bg-primary flex items-center justify-center flex-shrink-0 shadow-glow"
          >
            {isPlaying ? (
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path
                  fillRule="evenodd"
                  d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                  clipRule="evenodd"
                />
              </svg>
            ) : (
              <svg className="w-5 h-5 text-white ml-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
              </svg>
            )}
          </button>
        </div>
      </motion.div>

      {/* Full Screen Player */}
      <FullScreenPlayer
        isOpen={showFullScreen}
        onClose={() => setShowFullScreen(false)}
      />
    </>
  );
};

export default MiniPlayer;
