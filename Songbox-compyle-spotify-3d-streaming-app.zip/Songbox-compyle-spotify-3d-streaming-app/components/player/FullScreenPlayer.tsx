'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import { useAudioStore } from '@/store/audioStore';
import { useUserStore } from '@/store/userStore';
import { formatDuration } from '@/lib/utils';
import LyricsModal from '@/components/lyrics/LyricsModal';

interface FullScreenPlayerProps {
  isOpen: boolean;
  onClose: () => void;
}

const FullScreenPlayer: React.FC<FullScreenPlayerProps> = ({ isOpen, onClose }) => {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    repeat,
    shuffle,
    togglePlay,
    playNext,
    playPrevious,
    seekTo,
    setVolume,
    setRepeat,
    toggleShuffle,
  } = useAudioStore();

  const { toggleLike, isLiked } = useUserStore();
  const [showLyrics, setShowLyrics] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  if (!currentTrack) {
    return null;
  }

  const liked = isLiked(currentTrack.id);
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = (parseFloat(e.target.value) / 100) * duration;
    seekTo(newTime);
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed inset-0 z-50 bg-gradient-to-b from-background via-background-surface to-background flex flex-col md:hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <button
                onClick={onClose}
                className="p-2 -ml-2 hover:bg-white/5 rounded-lg transition-colors"
              >
                <svg className="w-6 h-6 text-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <p className="text-sm font-medium text-foreground-secondary">Now Playing</p>
              <div className="w-10" />
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-6 py-8 flex flex-col">
              {/* Album Art */}
              <div className="flex-shrink-0 mb-8">
                {currentTrack.artwork ? (
                  <Image
                    src={currentTrack.artwork}
                    alt={currentTrack.title}
                    width={400}
                    height={400}
                    className="w-full aspect-square rounded-2xl object-cover shadow-2xl"
                  />
                ) : (
                  <div className="w-full aspect-square rounded-2xl bg-gradient-to-br from-primary/30 to-secondary/30 shadow-2xl" />
                )}
              </div>

              {/* Track Info */}
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-foreground mb-2">
                  {currentTrack.title}
                </h1>
                <p className="text-lg text-foreground-secondary">
                  {currentTrack.artist}
                </p>
              </div>

              {/* Progress Bar */}
              <div className="mb-2">
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="0.1"
                  value={progress}
                  onChange={handleSeek}
                  onMouseDown={() => setIsDragging(true)}
                  onMouseUp={() => setIsDragging(false)}
                  onTouchStart={() => setIsDragging(true)}
                  onTouchEnd={() => setIsDragging(false)}
                  className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-primary"
                  style={{
                    background: `linear-gradient(to right, #6366f1 0%, #6366f1 ${progress}%, rgba(255,255,255,0.1) ${progress}%, rgba(255,255,255,0.1) 100%)`,
                  }}
                />
              </div>

              {/* Time */}
              <div className="flex items-center justify-between text-xs text-foreground-secondary mb-8">
                <span>{formatDuration(currentTime)}</span>
                <span>{formatDuration(duration)}</span>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-6 mb-8">
                {/* Shuffle */}
                <button
                  onClick={toggleShuffle}
                  className={`p-2 transition-colors ${
                    shuffle ? 'text-primary' : 'text-foreground-secondary'
                  }`}
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4 3a1 1 0 000 2h1.5L2 8.5a1 1 0 001.5 1.5L7 6.5V8a1 1 0 102 0V4a1 1 0 00-1-1H4zm12 0a1 1 0 000 2h-1.5l3.5 3.5a1 1 0 01-1.5 1.5L13 6.5V8a1 1 0 11-2 0V4a1 1 0 011-1h4z" />
                  </svg>
                </button>

                {/* Previous */}
                <button
                  onClick={playPrevious}
                  className="p-3 text-foreground hover:text-primary transition-colors"
                >
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M8.445 14.832A1 1 0 0010 14v-2.798l5.445 3.63A1 1 0 0017 14V6a1 1 0 00-1.555-.832L10 8.798V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z" />
                  </svg>
                </button>

                {/* Play/Pause */}
                <button
                  onClick={togglePlay}
                  className="w-20 h-20 rounded-full bg-primary flex items-center justify-center shadow-glow hover:bg-primary-dark transition-colors"
                >
                  {isPlaying ? (
                    <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    <svg className="w-10 h-10 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                    </svg>
                  )}
                </button>

                {/* Next */}
                <button
                  onClick={playNext}
                  className="p-3 text-foreground hover:text-primary transition-colors"
                >
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 11.202V14a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4A1 1 0 0010 6v2.798l-5.445-3.63z" />
                  </svg>
                </button>

                {/* Repeat */}
                <button
                  onClick={() => {
                    const modes: Array<typeof repeat> = ['off', 'one', 'all'];
                    const index = modes.indexOf(repeat);
                    setRepeat(modes[(index + 1) % modes.length]);
                  }}
                  className={`p-2 transition-colors ${
                    repeat !== 'off' ? 'text-primary' : 'text-foreground-secondary'
                  }`}
                >
                  {repeat === 'one' ? (
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      <text x="12" y="16" fontSize="10" textAnchor="middle" fill="currentColor">1</text>
                    </svg>
                  ) : (
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  )}
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-around py-6 border-t border-white/10">
                {/* Like */}
                <button
                  onClick={() => toggleLike(currentTrack.id)}
                  className={`p-3 rounded-full transition-colors ${
                    liked ? 'text-primary bg-primary/20' : 'text-foreground-secondary bg-white/5'
                  }`}
                >
                  <svg className="w-6 h-6" fill={liked ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                    />
                  </svg>
                </button>

                {/* Lyrics */}
                <button
                  onClick={() => setShowLyrics(true)}
                  className="p-3 rounded-full bg-white/5 text-foreground-secondary hover:bg-white/10 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </button>

                {/* Queue */}
                <button className="p-3 rounded-full bg-white/5 text-foreground-secondary hover:bg-white/10 transition-colors">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </button>

                {/* Share */}
                <button className="p-3 rounded-full bg-white/5 text-foreground-secondary hover:bg-white/10 transition-colors">
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
                    />
                  </svg>
                </button>
              </div>

              {/* Volume */}
              <div className="flex items-center gap-3 px-4 py-6 border-t border-white/10">
                <svg className="w-5 h-5 text-foreground-secondary flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM12.293 7.293a1 1 0 011.414 0L15 8.586l1.293-1.293a1 1 0 111.414 1.414L16.414 10l1.293 1.293a1 1 0 01-1.414 1.414L15 11.414l-1.293 1.293a1 1 0 01-1.414-1.414L13.586 10l-1.293-1.293a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  />
                </svg>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="flex-1 accent-primary"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Lyrics Modal */}
      <LyricsModal isOpen={showLyrics} onClose={() => setShowLyrics(false)} track={currentTrack} />
    </>
  );
};

export default FullScreenPlayer;
