'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Track } from '@/types/track';
import { generateMoodPlaylist } from '@/lib/recommendations';
import { getMoodColors, getMoodDescription, getMoodEmoji, MoodCategory } from '@/lib/mood-detection';
import TrackCard from '@/components/track/TrackCard';
import GlassPanel from '@/components/ui/GlassPanel';

interface MoodPlaylistSectionProps {
  mood: MoodCategory;
  title: string;
}

const MoodPlaylistSection: React.FC<MoodPlaylistSectionProps> = ({ mood, title }) => {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    loadMoodPlaylist();
  }, [mood]);

  const loadMoodPlaylist = async () => {
    try {
      setLoading(true);
      const playlist = await generateMoodPlaylist(mood, 20);
      setTracks(playlist);
    } catch (error) {
      console.error(`Error loading ${mood} playlist:`, error);
    } finally {
      setLoading(false);
    }
  };

  const moodColors = getMoodColors(mood);
  const moodEmoji = getMoodEmoji(mood);
  const description = getMoodDescription(mood);

  const displayTracks = expanded ? tracks : tracks.slice(0, 5);

  return (
    <div className="mb-8">
      {/* Header */}
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-2">
          <span>{moodEmoji}</span>
          <span>{title}</span>
        </h2>
        <p className="text-foreground-secondary text-sm">{description}</p>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-square bg-white/5 rounded-lg mb-3" />
              <div className="h-4 bg-white/5 rounded mb-2" />
              <div className="h-3 bg-white/5 rounded w-2/3" />
            </div>
          ))}
        </div>
      )}

      {/* Tracks Grid */}
      {!loading && tracks.length > 0 && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {displayTracks.map((track) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <TrackCard track={track} playlist={tracks} />
              </motion.div>
            ))}
          </div>

          {/* Show More/Less Button */}
          {tracks.length > 5 && (
            <div className="flex justify-center mt-6">
              <button
                onClick={() => setExpanded(!expanded)}
                className="px-6 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-foreground text-sm font-medium transition-colors"
              >
                {expanded ? 'Show Less' : `Show More (${tracks.length - 5} more)`}
              </button>
            </div>
          )}
        </>
      )}

      {/* Empty State */}
      {!loading && tracks.length === 0 && (
        <GlassPanel padding="lg" className="text-center">
          <p className="text-foreground-secondary">No tracks found for this mood. Try again later.</p>
        </GlassPanel>
      )}
    </div>
  );
};

// Main component with all mood playlists
const MoodPlaylists: React.FC = () => {
  return (
    <div className="space-y-12">
      <MoodPlaylistSection mood="energetic" title="Your Energy Mix" />
      <MoodPlaylistSection mood="chill" title="Chill Vibes" />
      <MoodPlaylistSection mood="happy" title="Feel Good" />
      <MoodPlaylistSection mood="melancholic" title="Late Night Feels" />
      <MoodPlaylistSection mood="focus" title="Focus Mode" />
    </div>
  );
};

export default MoodPlaylists;
