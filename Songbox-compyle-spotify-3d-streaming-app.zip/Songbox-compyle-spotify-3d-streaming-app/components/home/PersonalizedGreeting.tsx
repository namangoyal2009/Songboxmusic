'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useUserStore } from '@/store/userStore';
import { getPersonalizedGreeting } from '@/lib/recommendations';
import { getMoodEmoji, getMoodColors } from '@/lib/mood-detection';
import { fetchTrackMetadata } from '@/lib/audius';
import { Track } from '@/types/track';
import GlassPanel from '@/components/ui/GlassPanel';

const PersonalizedGreeting: React.FC = () => {
  const { user, likedSongs, listeningHistory } = useUserStore();
  const [greeting, setGreeting] = useState({
    greeting: 'Good day',
    tagline: 'Discover your next favorite',
    mood: 'energetic' as const,
  });
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserTracksAndGreeting();
  }, [likedSongs, listeningHistory]);

  const loadUserTracksAndGreeting = async () => {
    try {
      setLoading(true);

      // Combine liked songs and listening history
      const uniqueTrackIds = new Set([
        ...Array.from(likedSongs),
        ...listeningHistory.slice(0, 20).map((h) => h.trackId), // Last 20 plays
      ]);

      // Fetch track metadata for analysis
      const tracks = await Promise.all(
        Array.from(uniqueTrackIds)
          .slice(0, 30) // Limit to 30 tracks for performance
          .map((id) => fetchTrackMetadata(id))
      );

      const validTracks = tracks.filter((t) => t !== null) as Track[];
      setAllTracks(validTracks);

      // Generate personalized greeting
      const userProfile = {
        likedSongs,
        listeningHistory: listeningHistory.slice(0, 50), // Last 50 plays
      };

      const personalizedGreeting = getPersonalizedGreeting(userProfile, validTracks);
      setGreeting(personalizedGreeting);
    } catch (error) {
      console.error('Error loading personalized greeting:', error);
    } finally {
      setLoading(false);
    }
  };

  const moodColors = getMoodColors(greeting.mood);
  const moodEmoji = getMoodEmoji(greeting.mood);

  return (
    <GlassPanel padding="xl" className="mb-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {loading ? (
          // Loading skeleton
          <div className="animate-pulse">
            <div className="h-10 bg-white/5 rounded w-1/2 mb-3" />
            <div className="h-6 bg-white/5 rounded w-1/3" />
          </div>
        ) : (
          <>
            {/* Greeting */}
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-3">
              {greeting.greeting}
              {user && `, ${user.username || 'there'}`} {moodEmoji}
            </h1>

            {/* Tagline */}
            <p
              className="text-xl md:text-2xl font-medium mb-4"
              style={{
                background: `linear-gradient(to right, ${moodColors.from}, ${moodColors.to})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              {greeting.tagline}
            </p>

            {/* Stats (if user has history) */}
            {allTracks.length > 0 && (
              <div className="flex items-center gap-6 text-sm text-foreground-secondary">
                <div className="flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  <span>{likedSongs.size} liked songs</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                    <path
                      fillRule="evenodd"
                      d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <span>{listeningHistory.length} plays</span>
                </div>
              </div>
            )}
          </>
        )}
      </motion.div>
    </GlassPanel>
  );
};

export default PersonalizedGreeting;
