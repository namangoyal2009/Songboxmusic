'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import GlassPanel from '@/components/ui/GlassPanel';
import Button from '@/components/ui/Button';
import { useAudioStore } from '@/store/audioStore';
import { formatDuration } from '@/lib/utils';
import { useKeyboardShortcuts } from '@/lib/hooks/useKeyboardShortcuts';
import LyricsModal from '@/components/lyrics/LyricsModal';

const BottomPlayer: React.FC = () => {
  const {
    currentTrack,
    isPlaying,
    isLoading,
    currentTime,
    duration,
    volume,
    isMuted,
    repeat,
    shuffle,
    togglePlay,
    playNext,
    playPrevious,
    seekTo,
    setVolume,
    toggleMute,
    setRepeat,
    toggleShuffle,
  } = useAudioStore();

  // Enable keyboard shortcuts
  useKeyboardShortcuts();

  const [isDragging, setIsDragging] = useState(false);
  const [tempTime, setTempTime] = useState(0);
  const [showLyrics, setShowLyrics] = useState(false);
  const progressRef = useRef<HTMLDivElement>(null);

  const displayTime = isDragging ? tempTime : currentTime;
  const progress = duration > 0 ? (displayTime / duration) * 100 : 0;

  // Handle progress bar click/drag
  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current || duration === 0) return;

    const rect = progressRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, x / rect.width));
    const newTime = percentage * duration;

    seekTo(newTime);
  };

  const handleProgressMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    handleProgressMove(e);
  };

  const handleProgressMove = (e: React.MouseEvent | MouseEvent) => {
    if (!progressRef.current || duration === 0) return;

    const rect = progressRef.current.getBoundingClientRect();
    const x = (e as MouseEvent).clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, x / rect.width));
    const newTime = percentage * duration;

    if (isDragging) {
      setTempTime(newTime);
    }
  };

  useEffect(() => {
    const handleMouseUp = () => {
      if (isDragging) {
        seekTo(tempTime);
        setIsDragging(false);
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        handleProgressMove(e);
      }
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, tempTime]);

  if (!currentTrack) {
    return (
      <GlassPanel
        opacity={0.15}
        className="fixed bottom-0 left-0 right-0 z-30"
        rounded="none"
        padding="none"
      >
        <div className="flex items-center justify-center px-4 py-3 md:px-6">
          <p className="text-sm text-foreground-secondary">No track playing - Browse and select music to start</p>
        </div>
      </GlassPanel>
    );
  }

  return (
    <GlassPanel
      opacity={0.15}
      className="fixed bottom-0 left-0 right-0 z-30"
      rounded="none"
      padding="none"
    >
      <div className="px-4 py-3 md:px-6">
        {/* Progress Bar */}
        <div
          ref={progressRef}
          className="absolute top-0 left-0 right-0 h-1 bg-white/10 cursor-pointer group"
          onMouseDown={handleProgressMouseDown}
          onClick={handleProgressClick}
        >
          <div
            className="h-full bg-primary transition-all duration-100 relative"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg" />
          </div>
        </div>

        <div className="flex items-center justify-between gap-4 pt-2">
          {/* Track Info (Left) */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {currentTrack.artwork ? (
              <Image
                src={currentTrack.artwork}
                alt={currentTrack.title}
                width={48}
                height={48}
                className="w-12 h-12 rounded-md object-cover flex-shrink-0"
              />
            ) : (
              <div className="w-12 h-12 rounded-md bg-gradient-to-br from-primary/30 to-secondary/30 flex-shrink-0" />
            )}
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {currentTrack.title}
              </p>
              <p className="text-xs text-foreground-secondary truncate">
                {currentTrack.artist}
              </p>
            </div>
          </div>

          {/* Playback Controls (Center) */}
          <div className="hidden md:flex flex-col items-center gap-2 flex-1 max-w-2xl">
            <div className="flex items-center gap-4">
              {/* Shuffle */}
              <button
                onClick={toggleShuffle}
                className={`transition-colors ${
                  shuffle ? 'text-primary' : 'text-foreground-secondary hover:text-foreground'
                }`}
                aria-label="Toggle shuffle"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M4 3a1 1 0 000 2h1.5L2 8.5a1 1 0 001.5 1.5L7 6.5V8a1 1 0 102 0V4a1 1 0 00-1-1H4zm12 0a1 1 0 000 2h-1.5l3.5 3.5a1 1 0 01-1.5 1.5L13 6.5V8a1 1 0 11-2 0V4a1 1 0 011-1h4z" />
                </svg>
              </button>

              {/* Previous */}
              <button
                onClick={playPrevious}
                className="text-foreground-secondary hover:text-foreground transition-colors"
                aria-label="Previous"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M8.445 14.832A1 1 0 0010 14v-2.798l5.445 3.63A1 1 0 0017 14V6a1 1 0 00-1.555-.832L10 8.798V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z" />
                </svg>
              </button>

              {/* Play/Pause */}
              <Button
                variant="primary"
                size="md"
                className="rounded-full w-10 h-10 p-0 shadow-glow"
                onClick={togglePlay}
                isLoading={isLoading}
                aria-label={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                      clipRule="evenodd"
                    />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                  </svg>
                )}
              </Button>

              {/* Next */}
              <button
                onClick={playNext}
                className="text-foreground-secondary hover:text-foreground transition-colors"
                aria-label="Next"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 11.202V14a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4A1 1 0 0010 6v2.798l-5.445-3.63z" />
                </svg>
              </button>

              {/* Repeat */}
              <button
                onClick={() => {
                  const modes: Array<typeof repeat> = ['off', 'one', 'all'];
                  const index = modes.indexOf(repeat);
                  setRepeat(modes[(index + 1) % modes.length]);
                }}
                className={`transition-colors ${
                  repeat !== 'off' ? 'text-primary' : 'text-foreground-secondary hover:text-foreground'
                }`}
                aria-label="Toggle repeat"
              >
                {repeat === 'one' ? (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    <text x="12" y="16" fontSize="10" textAnchor="middle" fill="currentColor">1</text>
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                )}
              </button>
            </div>

            {/* Time Display */}
            <div className="flex items-center gap-2 text-xs text-foreground-secondary w-full">
              <span className="tabular-nums">{formatDuration(displayTime)}</span>
              <span className="flex-1" />
              <span className="tabular-nums">{formatDuration(duration)}</span>
            </div>
          </div>

          {/* Volume & Actions (Right) */}
          <div className="hidden md:flex items-center gap-3 flex-1 justify-end">
            {/* Lyrics Button */}
            <button
              onClick={() => setShowLyrics(true)}
              className="text-foreground-secondary hover:text-foreground transition-colors"
              aria-label="Show lyrics"
              title="Show lyrics"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </button>

            {/* Volume */}
            <button
              onClick={toggleMute}
              className="text-foreground-secondary hover:text-foreground transition-colors"
              aria-label={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || volume === 0 ? (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM12.293 7.293a1 1 0 011.414 0L15 8.586l1.293-1.293a1 1 0 111.414 1.414L16.414 10l1.293 1.293a1 1 0 01-1.414 1.414L15 11.414l-1.293 1.293a1 1 0 01-1.414-1.414L13.586 10l-1.293-1.293a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z"
                    clipRule="evenodd"
                  />
                </svg>
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-24 accent-primary"
              aria-label="Volume"
            />
          </div>

          {/* Mobile Play Button */}
          <div className="md:hidden">
            <Button
              variant="primary"
              size="sm"
              className="rounded-full"
              onClick={togglePlay}
              isLoading={isLoading}
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z"
                    clipRule="evenodd"
                  />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                </svg>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Lyrics Modal */}
      <LyricsModal isOpen={showLyrics} onClose={() => setShowLyrics(false)} track={currentTrack} />
    </GlassPanel>
  );
};

export default BottomPlayer;
