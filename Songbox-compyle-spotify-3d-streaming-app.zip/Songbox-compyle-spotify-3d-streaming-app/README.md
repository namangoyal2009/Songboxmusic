# 🎵 Songbox - 3D Music Streaming App

> Immersive 3D music streaming powered by Audius with AI recommendations, offline playback, and synchronized lyrics

![Phase](https://img.shields.io/badge/Phase-8%20Complete-success)
![Next.js](https://img.shields.io/badge/Next.js-14+-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue)
![PWA](https://img.shields.io/badge/PWA-Ready-purple)

## ✨ Features

### 🎨 **3D Visualizers**
- Particle Field, Geometric Wave, and Abstract Shapes modes
- Real-time audio-reactive animations
- Mood-based auto-switching
- 60fps desktop, 30fps mobile

### 🤖 **AI-Powered**
- Smart recommendations based on listening history
- Mood detection (5 categories)
- Auto-generated playlists
- Personalized greetings

### 📥 **Offline & Background**
- Download tracks for offline playback
- Background playback with lock screen controls
- Media Session API integration
- IndexedDB storage

### 🎵 **Lyrics Integration**
- Lyrics.ovh + Musixmatch sources
- Smart caching
- Beautiful glassmorphism display

### 📱 **Progressive Web App**
- Installable on iOS/Android
- Service worker with caching
- Offline support
- App-like standalone mode

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Set up environment
cp .env.example .env.local
# Edit .env.local with your credentials

# Run development server
npm run dev
```

## 🔧 Environment Variables

Required variables in `.env.local`:

```env
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key

NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

GOOGLE_CLIENT_ID=your-google-id (optional)
GOOGLE_CLIENT_SECRET=your-google-secret (optional)
MUSIXMATCH_API_KEY=your-musixmatch-key (optional)
```

## 📦 Tech Stack

- Next.js 14, React 18, TypeScript
- Tailwind CSS, Framer Motion
- React Three Fiber, Three.js
- Howler.js, Web Audio API
- Zustand, Supabase
- NextAuth.js, IndexedDB

## 🎯 Phases Complete

✅ Phase 1-8: Core Foundation → Polish & Deployment

All features implemented and ready for production!

## 🚢 Deploy to Vercel

```bash
vercel
```

---

Built with ❤️ using Next.js, React Three Fiber, and Audius

**Songbox** - Your immersive music universe 🎵✨
