import { create } from 'zustand';
import { Track, RepeatMode, QueueTrack } from '@/types/track';
import { getAudioEngine } from '@/lib/audio-engine';
import { shuffleArray } from '@/lib/utils';

interface AudioState {
  // Current playback
  currentTrack: Track | null;
  playlist: Track[];
  currentIndex: number;

  // Playback state
  isPlaying: boolean;
  isLoading: boolean;
  currentTime: number;
  duration: number;

  // Controls
  volume: number;
  isMuted: boolean;
  repeat: RepeatMode;
  shuffle: boolean;

  // Queue
  queue: QueueTrack[];

  // Actions
  playTrack: (track: Track, playlist?: Track[]) => void;
  pauseTrack: () => void;
  togglePlay: () => void;
  playNext: () => void;
  playPrevious: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setRepeat: (mode: RepeatMode) => void;
  toggleShuffle: () => void;
  addToQueue: (track: Track) => void;
  removeFromQueue: (queueId: string) => void;
  clearQueue: () => void;
  setCurrentTime: (time: number) => void;
  setDuration: (duration: number) => void;
  setIsLoading: (loading: boolean) => void;
}

export const useAudioStore = create<AudioState>((set, get) => {
  const audioEngine = getAudioEngine();

  // Setup audio engine callbacks
  audioEngine.onPlay = () => {
    set({ isPlaying: true, isLoading: false });
  };

  audioEngine.onPause = () => {
    set({ isPlaying: false });
  };

  audioEngine.onEnd = () => {
    // Auto play next track
    const { repeat } = get();
    if (repeat === 'one') {
      audioEngine.seek(0);
      audioEngine.play();
    } else {
      get().playNext();
    }
  };

  audioEngine.onLoad = () => {
    set({
      isLoading: false,
      duration: audioEngine.getDuration(),
    });

    // Update Media Session API
    updateMediaSession(get().currentTrack);
  };

  audioEngine.onTimeUpdate = (currentTime) => {
    set({ currentTime });
  };

  audioEngine.onError = (error) => {
    console.error('Audio playback error:', error);
    set({ isLoading: false, isPlaying: false });
    // Try next track on error
    setTimeout(() => get().playNext(), 1000);
  };

  return {
    // Initial state
    currentTrack: null,
    playlist: [],
    currentIndex: -1,
    isPlaying: false,
    isLoading: false,
    currentTime: 0,
    duration: 0,
    volume: 0.7,
    isMuted: false,
    repeat: 'off',
    shuffle: false,
    queue: [],

    // Play track
    playTrack: (track, playlist) => {
      set({ isLoading: true });

      const { queue } = get();

      // If there's a queue, play from queue
      if (queue.length > 0) {
        const queueTrack = queue[0];
        set({
          currentTrack: queueTrack,
          queue: queue.slice(1),
          currentIndex: -1, // Playing from queue
          currentTime: 0,
        });
        audioEngine.load(queueTrack);
        audioEngine.play();
        return;
      }

      // Update playlist if provided
      if (playlist) {
        const index = playlist.findIndex((t) => t.id === track.id);
        set({
          playlist,
          currentIndex: index !== -1 ? index : 0,
        });
      }

      set({
        currentTrack: track,
        currentTime: 0,
      });

      audioEngine.load(track);
      audioEngine.play();
    },

    // Pause track
    pauseTrack: () => {
      audioEngine.pause();
    },

    // Toggle play/pause
    togglePlay: () => {
      const { currentTrack } = get();
      if (!currentTrack) return;

      audioEngine.togglePlay();
    },

    // Play next track
    playNext: () => {
      const { playlist, currentIndex, repeat, shuffle: isShuffled, queue } = get();

      // Play from queue if available
      if (queue.length > 0) {
        const nextTrack = queue[0];
        set({
          currentTrack: nextTrack,
          queue: queue.slice(1),
          currentTime: 0,
        });
        audioEngine.load(nextTrack);
        audioEngine.play();
        return;
      }

      if (playlist.length === 0) return;

      let nextIndex: number;

      if (isShuffled) {
        // Random next track (avoid current)
        const availableIndices = playlist
          .map((_, i) => i)
          .filter((i) => i !== currentIndex);
        nextIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
      } else {
        nextIndex = currentIndex + 1;

        // Handle end of playlist
        if (nextIndex >= playlist.length) {
          if (repeat === 'all') {
            nextIndex = 0;
          } else {
            // End of playlist, stop
            audioEngine.stop();
            set({ isPlaying: false, currentTime: 0 });
            return;
          }
        }
      }

      const nextTrack = playlist[nextIndex];
      set({
        currentTrack: nextTrack,
        currentIndex: nextIndex,
        currentTime: 0,
      });

      audioEngine.load(nextTrack);
      audioEngine.play();
    },

    // Play previous track
    playPrevious: () => {
      const { playlist, currentIndex, currentTime } = get();

      // If more than 3 seconds played, restart current track
      if (currentTime > 3) {
        audioEngine.seek(0);
        return;
      }

      if (playlist.length === 0 || currentIndex <= 0) {
        audioEngine.seek(0);
        return;
      }

      const prevIndex = currentIndex - 1;
      const prevTrack = playlist[prevIndex];

      set({
        currentTrack: prevTrack,
        currentIndex: prevIndex,
        currentTime: 0,
      });

      audioEngine.load(prevTrack);
      audioEngine.play();
    },

    // Seek to position
    seekTo: (seconds) => {
      audioEngine.seek(seconds);
      set({ currentTime: seconds });
    },

    // Set volume
    setVolume: (volume) => {
      audioEngine.setVolume(volume);
      set({ volume, isMuted: false });

      // Save to localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem('songbox_volume', volume.toString());
      }
    },

    // Toggle mute
    toggleMute: () => {
      const { isMuted } = get();
      audioEngine.toggleMute();
      set({ isMuted: !isMuted });
    },

    // Set repeat mode
    setRepeat: (mode) => {
      set({ repeat: mode });
    },

    // Toggle shuffle
    toggleShuffle: () => {
      const { shuffle: currentShuffle, playlist, currentIndex } = get();
      const newShuffle = !currentShuffle;

      if (newShuffle && playlist.length > 1) {
        // Shuffle playlist, keeping current track at current position
        const currentTrack = playlist[currentIndex];
        const otherTracks = playlist.filter((_, i) => i !== currentIndex);
        const shuffled = shuffleArray(otherTracks);
        const newPlaylist = [
          ...playlist.slice(0, currentIndex),
          currentTrack,
          ...shuffled,
        ];
        set({ playlist: newPlaylist, shuffle: newShuffle });
      } else {
        set({ shuffle: newShuffle });
      }
    },

    // Add to queue
    addToQueue: (track) => {
      const queueTrack: QueueTrack = {
        ...track,
        queueId: `${track.id}-${Date.now()}`,
        addedAt: Date.now(),
      };
      set((state) => ({
        queue: [...state.queue, queueTrack],
      }));
    },

    // Remove from queue
    removeFromQueue: (queueId) => {
      set((state) => ({
        queue: state.queue.filter((t) => t.queueId !== queueId),
      }));
    },

    // Clear queue
    clearQueue: () => {
      set({ queue: [] });
    },

    // Set current time (from progress bar)
    setCurrentTime: (time) => {
      set({ currentTime: time });
    },

    // Set duration
    setDuration: (duration) => {
      set({ duration });
    },

    // Set loading state
    setIsLoading: (loading) => {
      set({ isLoading: loading });
    },
  };
});

// Update Media Session API for lock screen controls
function updateMediaSession(track: Track | null) {
  if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;
  if (!track) return;

  navigator.mediaSession.metadata = new MediaMetadata({
    title: track.title,
    artist: track.artist,
    album: track.genre,
    artwork: [
      { src: track.artwork, sizes: '512x512', type: 'image/jpeg' },
    ],
  });

  // Setup action handlers
  navigator.mediaSession.setActionHandler('play', () => {
    useAudioStore.getState().togglePlay();
  });

  navigator.mediaSession.setActionHandler('pause', () => {
    useAudioStore.getState().pauseTrack();
  });

  navigator.mediaSession.setActionHandler('nexttrack', () => {
    useAudioStore.getState().playNext();
  });

  navigator.mediaSession.setActionHandler('previoustrack', () => {
    useAudioStore.getState().playPrevious();
  });
}
