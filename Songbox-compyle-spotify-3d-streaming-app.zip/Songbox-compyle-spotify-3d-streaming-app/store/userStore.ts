import { create } from 'zustand';
import { Track } from '@/types/track';

export interface UserPreferences {
  theme: 'light' | 'dark';
  visualizerMode: 'particle' | 'wave' | 'shapes' | 'auto';
  vibeMode: boolean;
  volume: number;
}

export interface User {
  id: string;
  email: string;
  username: string | null;
  avatarUrl: string | null;
  preferences: UserPreferences;
}

interface UserState {
  user: User | null;
  isAuthenticated: boolean;
  likedSongs: Set<string>; // Audius track IDs
  playlists: Playlist[];
  listeningHistory: HistoryEntry[];

  // Actions
  setUser: (user: User | null) => void;
  updatePreferences: (preferences: Partial<UserPreferences>) => void;

  // Liked songs
  toggleLike: (trackId: string) => void;
  isLiked: (trackId: string) => boolean;
  getLikedSongs: () => string[];

  // Playlists
  addPlaylist: (playlist: Playlist) => void;
  updatePlaylist: (playlistId: string, updates: Partial<Playlist>) => void;
  deletePlaylist: (playlistId: string) => void;
  addTrackToPlaylist: (playlistId: string, trackId: string) => void;
  removeTrackFromPlaylist: (playlistId: string, trackId: string) => void;

  // Listening history
  addToHistory: (track: Track, duration: number) => void;
  getRecentHistory: (limit?: number) => HistoryEntry[];

  // Sync
  syncFromServer: (data: SyncData) => void;
  loadFromLocalStorage: () => void;
  saveToLocalStorage: () => void;
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  coverImageUrl?: string;
  trackIds: string[];
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface HistoryEntry {
  trackId: string;
  playedAt: string;
  durationSeconds: number;
}

export interface SyncData {
  likedSongs: string[];
  playlists: Playlist[];
  listeningHistory: HistoryEntry[];
  preferences: UserPreferences;
}

const STORAGE_KEY = 'songbox_user_data';

export const useUserStore = create<UserState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  likedSongs: new Set<string>(),
  playlists: [],
  listeningHistory: [],

  setUser: (user) => {
    set({ user, isAuthenticated: !!user });
    if (user) {
      get().loadFromLocalStorage();
    }
  },

  updatePreferences: (preferences) => {
    const currentUser = get().user;
    if (currentUser) {
      set({
        user: {
          ...currentUser,
          preferences: { ...currentUser.preferences, ...preferences },
        },
      });
      get().saveToLocalStorage();
    }
  },

  // Liked songs
  toggleLike: (trackId) => {
    const likedSongs = new Set(get().likedSongs);
    if (likedSongs.has(trackId)) {
      likedSongs.delete(trackId);
    } else {
      likedSongs.add(trackId);
    }
    set({ likedSongs });
    get().saveToLocalStorage();
  },

  isLiked: (trackId) => {
    return get().likedSongs.has(trackId);
  },

  getLikedSongs: () => {
    return Array.from(get().likedSongs);
  },

  // Playlists
  addPlaylist: (playlist) => {
    set((state) => ({
      playlists: [...state.playlists, playlist],
    }));
    get().saveToLocalStorage();
  },

  updatePlaylist: (playlistId, updates) => {
    set((state) => ({
      playlists: state.playlists.map((p) =>
        p.id === playlistId ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
      ),
    }));
    get().saveToLocalStorage();
  },

  deletePlaylist: (playlistId) => {
    set((state) => ({
      playlists: state.playlists.filter((p) => p.id !== playlistId),
    }));
    get().saveToLocalStorage();
  },

  addTrackToPlaylist: (playlistId, trackId) => {
    set((state) => ({
      playlists: state.playlists.map((p) =>
        p.id === playlistId && !p.trackIds.includes(trackId)
          ? { ...p, trackIds: [...p.trackIds, trackId], updatedAt: new Date().toISOString() }
          : p
      ),
    }));
    get().saveToLocalStorage();
  },

  removeTrackFromPlaylist: (playlistId, trackId) => {
    set((state) => ({
      playlists: state.playlists.map((p) =>
        p.id === playlistId
          ? { ...p, trackIds: p.trackIds.filter((id) => id !== trackId), updatedAt: new Date().toISOString() }
          : p
      ),
    }));
    get().saveToLocalStorage();
  },

  // Listening history
  addToHistory: (track, duration) => {
    const entry: HistoryEntry = {
      trackId: track.id,
      playedAt: new Date().toISOString(),
      durationSeconds: duration,
    };
    set((state) => ({
      listeningHistory: [entry, ...state.listeningHistory].slice(0, 100), // Keep last 100
    }));
    get().saveToLocalStorage();
  },

  getRecentHistory: (limit = 20) => {
    return get().listeningHistory.slice(0, limit);
  },

  // Sync
  syncFromServer: (data) => {
    set({
      likedSongs: new Set(data.likedSongs),
      playlists: data.playlists,
      listeningHistory: data.listeningHistory,
    });
    if (get().user) {
      set((state) => ({
        user: state.user ? { ...state.user, preferences: data.preferences } : null,
      }));
    }
    get().saveToLocalStorage();
  },

  loadFromLocalStorage: () => {
    if (typeof window === 'undefined') return;

    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data: SyncData = JSON.parse(stored);
        set({
          likedSongs: new Set(data.likedSongs),
          playlists: data.playlists,
          listeningHistory: data.listeningHistory,
        });
      }
    } catch (error) {
      console.error('Error loading user data from localStorage:', error);
    }
  },

  saveToLocalStorage: () => {
    if (typeof window === 'undefined') return;

    try {
      const data: SyncData = {
        likedSongs: Array.from(get().likedSongs),
        playlists: get().playlists,
        listeningHistory: get().listeningHistory,
        preferences: get().user?.preferences || {
          theme: 'dark',
          visualizerMode: 'auto',
          vibeMode: true,
          volume: 0.7,
        },
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving user data to localStorage:', error);
    }
  },
}));
