/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: {DEFAULT: '#0a0a0a', surface: '#1a1a1a', card: '#1e1e1e'},
        foreground: {DEFAULT: '#ffffff', secondary: '#a1a1aa', muted: '#71717a'},
        primary: {DEFAULT: '#6366f1', light: '#818cf8', dark: '#4f46e5'},
        secondary: {DEFAULT: '#8b5cf6', light: '#a78bfa', dark: '#7c3aed'},
        success: '#10b981',
        warning: '#f59e0b',
        error: '#ef4444',
      },
    },
  },
  plugins: [],
};
