/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  compress: true,
  poweredByHeader: false,

  images: {
    remotePatterns: [
      {protocol: 'https', hostname: 'discoveryprovider.audius.co'},
      {protocol: 'https', hostname: '*.audius.co'},
    ],
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920],
    minimumCacheTTL: 604800, // 7 days
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {key: 'X-DNS-Prefetch-Control', value: 'on'},
          {key: 'X-Frame-Options', value: 'SAMEORIGIN'},
          {key: 'X-Content-Type-Options', value: 'nosniff'},
          {key: 'Referrer-Policy', value: 'origin-when-cross-origin'},
        ],
      },
      {
        source: '/sw.js',
        headers: [
          {key: 'Cache-Control', value: 'public, max-age=0, must-revalidate'},
          {key: 'Service-Worker-Allowed', value: '/'},
        ],
      },
    ];
  },

  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.optimization = {
        ...config.optimization,
        splitChunks: {
          chunks: 'all',
          cacheGroups: {
            vendor: {
              name: 'vendor',
              test: /node_modules/,
              priority: 20,
            },
            three: {
              name: 'three',
              test: /[\\/]node_modules[\\/](three|@react-three)[\\/]/,
              priority: 30,
            },
          },
        },
      };
    }
    return config;
  },
};

module.exports = nextConfig;
