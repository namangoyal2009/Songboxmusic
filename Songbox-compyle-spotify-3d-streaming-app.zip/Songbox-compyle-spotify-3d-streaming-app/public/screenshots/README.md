# PWA Screenshots

This directory should contain screenshots for the Progressive Web App install dialog and app stores.

## Required Screenshots

### Desktop/Wide (1280x720)
- `home.png` - Home page showing the main interface with 3D visualizer

### Mobile/Narrow (750x1334)
- `mobile.png` - Mobile view showing the app interface

## Best Practices

1. **Resolution**: Use high-quality screenshots at 2x or 3x resolution
2. **Content**: Show the app in action with actual content
3. **Context**: Include key features visible in screenshots
4. **Text**: Avoid small text that's hard to read
5. **Branding**: Maintain consistent branding and colors

## Recommended Screenshots

### For Desktop (home.png):
- Show the 3D visualizer in action
- Display a track playing with the player controls
- Include the glassmorphism UI panels
- Show the personalized greeting and recommendations

### For Mobile (mobile.png):
- Show the mobile interface with bottom navigation
- Display a track card grid
- Include the mini player at the bottom
- Show responsive design elements

## How to Capture

### Desktop:
1. Open the app in a browser at 1280x720 viewport
2. Play a track to activate the visualizer
3. Use browser dev tools screenshot feature or:
   ```javascript
   // Run in console
   window.devicePixelRatio = 2;
   ```
4. Take screenshot

### Mobile:
1. Use mobile device or browser mobile emulation (375x667)
2. Ensure bottom navigation and mini player are visible
3. Capture at 2x resolution (750x1334)

## Placeholder

Until you have actual screenshots, you can create placeholders with your brand colors and logo using design tools like Figma, Canva, or Photoshop.
