# PWA Icons

This directory should contain the following icon files for the Progressive Web App:

## Required Icons

### Standard Icons
- `icon-72x72.png` - Small icon
- `icon-96x96.png` - Standard icon
- `icon-128x128.png` - Standard icon
- `icon-144x144.png` - Standard icon
- `icon-152x152.png` - Apple touch icon
- `icon-180x180.png` - Apple touch icon (iPhone)
- `icon-192x192.png` - Android icon
- `icon-384x384.png` - Large icon
- `icon-512x512.png` - Extra large icon

### Shortcut Icons (Optional)
- `trending.png` - 96x96 icon for trending shortcut
- `library.png` - 96x96 icon for library shortcut
- `search.png` - 96x96 icon for search shortcut

## Generating Icons

You can generate all required icons from a single source image (1024x1024) using:

### Option 1: Online Tools
- https://realfavicongenerator.net/
- https://www.pwabuilder.com/imageGenerator

### Option 2: Command Line (ImageMagick)
```bash
convert source-icon.png -resize 72x72 icon-72x72.png
convert source-icon.png -resize 96x96 icon-96x96.png
convert source-icon.png -resize 128x128 icon-128x128.png
convert source-icon.png -resize 144x144 icon-144x144.png
convert source-icon.png -resize 152x152 icon-152x152.png
convert source-icon.png -resize 180x180 icon-180x180.png
convert source-icon.png -resize 192x192 icon-192x192.png
convert source-icon.png -resize 384x384 icon-384x384.png
convert source-icon.png -resize 512x512 icon-512x512.png
```

### Option 3: Node.js Script
```javascript
const sharp = require('sharp');

const sizes = [72, 96, 128, 144, 152, 180, 192, 384, 512];

sizes.forEach(size => {
  sharp('source-icon.png')
    .resize(size, size)
    .toFile(`icon-${size}x${size}.png`);
});
```

## Design Recommendations

- **Maskable Icons**: Use safe area (80% of canvas) for important elements
- **Background**: Consider using a solid color or gradient
- **Logo**: Center the Songbox logo with adequate padding
- **Colors**: Use brand colors (#6366f1 primary, #8b5cf6 secondary)
- **Style**: Modern, minimal, recognizable at all sizes

## Temporary Placeholder

Until you generate proper icons, you can use a temporary placeholder by creating a simple colored square:

```bash
convert -size 512x512 xc:'#6366f1' -gravity center -pointsize 200 -fill white -annotate +0+0 'S' icon-512x512.png
```

Then resize it to all required sizes.
